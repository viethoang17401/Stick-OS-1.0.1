// A pool of audio elements to allow for overlapping sounds
const audioPool: HTMLAudioElement[] = [];
const POOL_SIZE = 15; // Increased pool size for more complex game sounds

for (let i = 0; i < POOL_SIZE; i++) {
    audioPool.push(new Audio());
}

let currentAudioIndex = 0;

export const playSound = (soundUrl: string, volume: number = 1.0) => {
    try {
        const audio = audioPool[currentAudioIndex];
        // Only change src if it's different to avoid interrupting the current sound if it's the same
        if (audio.src !== soundUrl) {
            audio.src = soundUrl;
        }
        audio.volume = volume;
        audio.currentTime = 0; // Play from the start
        audio.play().catch(error => {
            // Autoplay is often restricted by browsers until a user interaction.
            // This is a common issue, but since our sounds are triggered by user actions, it should be fine.
            // We'll log the error just in case.
            console.warn(`Audio playback failed for ${soundUrl}:`, error);
        });

        currentAudioIndex = (currentAudioIndex + 1) % POOL_SIZE;
    } catch (e) {
        console.error("Failed to play sound:", e);
    }
};

export const SOUNDS = {
    login: 'https://cdn.pixabay.com/download/audio/2022/11/22/audio_7658514a60.mp3', // System startup
    click: 'https://cdn.pixabay.com/download/audio/2021/08/04/audio_bb630cc098.mp3', // Simple click
    jump: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_13b63297b8.mp3', // Jump/swoosh
    gameOver: 'https://cdn.pixabay.com/download/audio/2022/03/10/audio_c382372481.mp3', // Game over/explosion (same as troll app)
    flip: 'https://cdn.pixabay.com/download/audio/2022/03/24/audio_138dc19b99.mp3', // Card flip
    match: 'https://cdn.pixabay.com/download/audio/2022/03/25/audio_9a079a3b34.mp3', // Success/match
    win: 'https://cdn.pixabay.com/download/audio/2022/01/24/audio_248c8b64e5.mp3', // Victory
    defuse: 'https://cdn.pixabay.com/download/audio/2022/03/22/audio_73b94a287a.mp3', // Short success
    explode: 'https://cdn.pixabay.com/download/audio/2022/03/10/audio_c382372481.mp3', // Explosion
    shoot: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_73588950d8.mp3', // Gunshot (already in FreeFire)
};
