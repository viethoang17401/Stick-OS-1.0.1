import React, { useState, useRef, useCallback } from 'react';
import { APPS } from '../constants';
import { useWindows } from '../hooks/useWindows';
import type { AppDefinition } from '../types';

// Các ứng dụng được ghim vào dock
const PINNED_APP_IDS = ['stickweb', 'gameon', 'stickface', 'sticknews', 'thispc', 'settings'];

const MAX_MAGNIFICATION = 2; // Độ phóng đại tối đa
const MAGNIFICATION_RANGE = 80; // Phạm vi ảnh hưởng của hiệu ứng phóng đại (tính bằng pixel)

interface DockProps {
  isHidden: boolean;
}

const Dock: React.FC<DockProps> = ({ isHidden }) => {
  const { windows, openWindow } = useWindows();
  const dockRef = useRef<HTMLDivElement>(null);
  const pinnedApps = APPS.filter(app => PINNED_APP_IDS.includes(app.id));
  const [scales, setScales] = useState<number[]>(() => Array(pinnedApps.length).fill(1));

  const runningAppIds = new Set(windows.map(win => win.appId));

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!dockRef.current) return;

    const dockRect = dockRef.current.getBoundingClientRect();
    const mouseX = e.clientX - dockRect.left;

    const newScales = pinnedApps.map((_, index) => {
      const iconElement = dockRef.current?.children[index] as HTMLElement;
      if (!iconElement) return 1;
      
      const iconRect = iconElement.getBoundingClientRect();
      const iconCenterX = iconRect.left - dockRect.left + iconRect.width / 2;
      
      const distance = Math.abs(mouseX - iconCenterX);

      if (distance < MAGNIFICATION_RANGE) {
        const scale = 1 + (MAX_MAGNIFICATION - 1) * (1 - distance / MAGNIFICATION_RANGE);
        return Math.max(1, scale);
      }
      
      return 1;
    });

    setScales(newScales);
  }, [pinnedApps]);

  const handleMouseLeave = useCallback(() => {
    setScales(Array(pinnedApps.length).fill(1));
  }, [pinnedApps.length]);

  const dockContainerClasses = `
    absolute bottom-14 left-1/2 -translate-x-1/2 z-[99998] 
    transition-all duration-300 ease-in-out
    ${isHidden ? 'opacity-0 translate-y-10 pointer-events-none' : 'opacity-100 translate-y-0'}
  `;

  return (
    <div className={dockContainerClasses}>
      <div
        ref={dockRef}
        className="flex items-end h-20 gap-2 p-2 backdrop-blur-md rounded-xl border shadow-lg"
        style={{ 
            backgroundColor: 'var(--primary-bg)',
            borderColor: 'var(--border-color)'
        }}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
      >
        {pinnedApps.map((app, index) => (
          <DockIcon
            key={app.id}
            app={app}
            isRunning={runningAppIds.has(app.id)}
            scale={scales[index]}
            onClick={() => openWindow(app.id)}
          />
        ))}
      </div>
    </div>
  );
};

interface DockIconProps {
  app: AppDefinition;
  isRunning: boolean;
  scale: number;
  onClick: () => void;
}

const DockIcon: React.FC<DockIconProps> = ({ app, isRunning, scale, onClick }) => {
  return (
    <div className="relative flex flex-col items-center gap-1">
      <button
        onClick={onClick}
        className="p-1 rounded-md transition-transform duration-100 ease-out will-change-transform"
        style={{ transform: `scale(${scale})` }}
        title={app.name}
      >
        {React.cloneElement(app.icon, { className: "w-12 h-12" })}
      </button>
      {isRunning && (
        <div 
          className="w-1.5 h-1.5 rounded-full shadow-md"
          style={{ backgroundColor: 'var(--accent-color)' }}
        />
      )}
    </div>
  );
};

export default Dock;