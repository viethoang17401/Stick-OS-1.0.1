import React, { useEffect, useRef } from 'react';

interface BSODProps {
    onReset: () => void;
}

const BSOD: React.FC<BSODProps> = ({ onReset }) => {
    const audioRef = useRef<HTMLAudioElement>(null);

    useEffect(() => {
        // Play error sound
        if (audioRef.current) {
            audioRef.current.play().catch(e => console.error("Audio play failed:", e));
        }
    }, []);

    return (
        <div className="w-screen h-screen bg-blue-800 text-white font-mono flex flex-col items-center justify-center p-8">
            <h1 className="text-5xl mb-8 text-center">:(</h1>
            <p className="text-xl mb-4 text-center">
                Máy tính của bạn đã gặp sự cố và cần khởi động lại.
            </p>
            <p className="text-lg mb-8 text-center">Chúng tôi chỉ đang thu thập một số thông tin lỗi, và sau đó chúng tôi sẽ khởi động lại cho bạn.</p>
            
            <div className="w-full max-w-lg text-sm mb-8">
                <p>Mã dừng: UIA_VIRUS_INFECTION</p>
                <p>Thông tin kỹ thuật:</p>
                <p>*** STOP: 0x000000DEAD (0xBAADF00D, 0xFEEDFADE, 0xDEADBEEF, 0x00000000)</p>
            </div>

            <button
                onClick={onReset}
                className="mt-8 bg-gray-200 text-blue-800 font-bold py-3 px-8 rounded-lg shadow-lg transform hover:scale-105 transition-transform"
            >
                Khởi động lại
            </button>
            <audio ref={audioRef} src="https://cdn.pixabay.com/download/audio/2022/10/24/audio_39c70acf24.mp3" style={{ display: 'none' }} />
        </div>
    );
};

export default BSOD;