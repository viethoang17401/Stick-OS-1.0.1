
import React, { useState, useEffect, useRef } from 'react';
import { APPS } from '../constants';
import { useWindows } from '../hooks/useWindows';
import { useSettings } from '../hooks/useSettings';
import { Power, Settings, User, LogOut, RefreshCw, XCircle, Lock, Bomb, Undo2 } from 'lucide-react';

interface StartMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onLogout: () => void;
}

const PINNED_TILES = ['thispc', 'stickweb', 'store', 'gameon', 'gptapp', 'sticknews'];

const StartMenu: React.FC<StartMenuProps> = ({ isOpen, onClose, onLogout }) => {
  const [showPowerDialog, setShowPowerDialog] = useState(false);
  const { openWindow, toggleHideAllWindows, windowsHidden } = useWindows();
  const { username, avatarUrl } = useSettings();
  const menuRef = useRef<HTMLDivElement>(null);

  const pinnedApps = APPS.filter(app => PINNED_TILES.includes(app.id));
  const appList = APPS
    .filter(app => !PINNED_TILES.includes(app.id)) // Don't show pinned apps in list
    .sort((a, b) => a.name.localeCompare(b.name, 'vi'));

  const handleAppClick = (appId: string) => {
    openWindow(appId);
    onClose();
  };

  const handleAction = () => {
    window.onbeforeunload = null;
    window.location.reload();
  };

  const handleLock = () => {
    setShowPowerDialog(false);
    onClose();
    onLogout();
  };

  // Close menu if clicked outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        const taskbarButton = document.getElementById('start-button');
        if (taskbarButton && !taskbarButton.contains(event.target as Node)) {
          onClose();
        }
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);


  const containerClasses = `
    absolute bottom-14 left-2 z-[99997]
    w-[600px] h-[550px]
    bg-slate-800/60 backdrop-blur-xl
    border border-white/10 rounded-lg
    flex overflow-hidden shadow-2xl
    transition-all duration-300 ease-out
    ${isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}
  `;

  return (
    <>
      <div ref={menuRef} className={containerClasses}>
        {/* Left Sidebar */}
        <div className="w-12 bg-black/20 flex flex-col justify-between items-center py-2 flex-shrink-0">
            <div>{/* Top Spacer */}</div>
            <div className="flex flex-col gap-1">
                {avatarUrl ? (
                    <img src={avatarUrl} alt="User Avatar" className="w-8 h-8 rounded-full object-cover" />
                ) : (
                    <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center">
                        <User size={18} />
                    </div>
                )}
                <button
                    onClick={() => handleAppClick('settings')}
                    className="p-2 rounded hover:bg-white/20 transition-colors"
                    title="Cài đặt"
                >
                    <Settings size={20} />
                </button>
            </div>
            <div className="flex flex-col items-center gap-1">
                <button
                    onClick={toggleHideAllWindows}
                    className="p-2 rounded hover:bg-white/20 transition-colors"
                    title={windowsHidden ? "Khôi phục các cửa sổ" : "Tự hủy"}
                >
                    {windowsHidden ? <Undo2 size={20} className="text-green-400" /> : <Bomb size={20} className="text-red-500" />}
                </button>
                <button
                    onClick={() => setShowPowerDialog(true)}
                    className="p-2 rounded hover:bg-white/20 transition-colors"
                    title="Tùy chọn nguồn"
                >
                    <Power size={20} />
                </button>
            </div>
        </div>

        {/* App List */}
        <div className="w-64 p-2 overflow-y-auto">
            <h2 className="text-sm font-semibold text-gray-300 px-2 pb-2">Tất cả ứng dụng</h2>
            {appList.map(app => (
                <button
                    key={app.id}
                    onClick={() => handleAppClick(app.id)}
                    className="w-full flex items-center gap-3 p-2 rounded hover:bg-white/10 transition-colors text-left"
                >
                    {React.cloneElement(app.icon, { className: "w-6 h-6" })}
                    <span className="text-sm">{app.name}</span>
                </button>
            ))}
        </div>

        {/* Pinned Tiles */}
        <div className="flex-grow p-4 overflow-y-auto bg-black/10">
             <h2 className="text-sm font-semibold text-gray-300 pb-2">Ghim</h2>
             <div className="grid grid-cols-3 gap-2">
                {pinnedApps.map(app => (
                    <button
                        key={app.id}
                        onClick={() => handleAppClick(app.id)}
                        className="aspect-square flex flex-col items-center justify-center text-center p-2 rounded-md hover:bg-white/10 transition-colors"
                        style={{ backgroundColor: 'var(--accent-color-light)'}}
                    >
                        {React.cloneElement(app.icon, { className: "w-8 h-8 mb-1" })}
                        <span className="text-xs font-medium w-full truncate">{app.name}</span>
                    </button>
                ))}
             </div>
        </div>
      </div>

      {showPowerDialog && (
         <div className="absolute inset-0 bg-black/60 backdrop-blur-sm z-[100000] flex items-center justify-center transition-opacity duration-300">
           <div className="bg-slate-800 text-white p-8 rounded-lg shadow-2xl w-full max-w-xs border border-white/10 animate-fade-in-up">
             <h2 className="text-xl font-bold mb-6 text-center">Bạn muốn làm gì?</h2>
             <div className="flex flex-col gap-4">
               <button
                 onClick={handleAction}
                 className="flex items-center justify-center gap-3 w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3 px-4 rounded-lg transition-all transform hover:scale-105"
               >
                 <LogOut size={20} />
                 <span>Tắt máy</span>
               </button>
               <button
                 onClick={handleAction}
                 className="flex items-center justify-center gap-3 w-full bg-orange-500 hover:bg-orange-600 text-white font-semibold py-3 px-4 rounded-lg transition-all transform hover:scale-105"
               >
                 <RefreshCw size={20} />
                 <span>Khởi động lại</span>
               </button>
               <button
                 onClick={handleLock}
                 className="flex items-center justify-center gap-3 w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-all transform hover:scale-105"
               >
                 <Lock size={20} />
                 <span>Về màn hình khóa</span>
               </button>
                <button
                 onClick={() => setShowPowerDialog(false)}
                 className="flex items-center justify-center gap-3 w-full bg-gray-600 hover:bg-gray-700 text-white font-semibold py-3 px-4 rounded-lg transition-all mt-4 transform hover:scale-105"
               >
                 <XCircle size={20} />
                 <span>Hủy</span>
               </button>
             </div>
           </div>
         </div>
      )}
    </>
  );
};

export default StartMenu;
