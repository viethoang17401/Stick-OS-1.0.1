import React, { Suspense, useRef, useState, useEffect } from 'react';
import { APPS, PREDEFINED_WALLPAPERS, STORE_ITEMS } from '../constants';
import DesktopIcon from './DesktopIcon';
import { useSettings } from '../hooks/useSettings';

const Desktop: React.FC = () => {
  const { wallpaperUrl, activeWidgets } = useSettings();
  const iconsContainerRef = useRef<HTMLDivElement>(null);
  const [iconPositions, setIconPositions] = useState<DOMRect[]>([]);
  
  // Lọc các ứng dụng trò chơi khỏi biểu tượng desktop, chúng sẽ nằm trong ứng dụng Trung tâm Game
  const desktopApps = APPS
    .filter(app => !['stickrunner', 'stickclicker', 'stickmemory', 'stickjump', 'botubomb', 'freefirehtml5'].includes(app.id))
    .sort((a, b) => a.name.localeCompare(b.name, 'vi')); // Sắp xếp ứng dụng theo thứ tự tên

  const currentWallpaper = PREDEFINED_WALLPAPERS.find(wp => wp.url === wallpaperUrl) || PREDEFINED_WALLPAPERS.find(wp => wp.id === 'default');

    useEffect(() => {
        const updatePositions = () => {
            if (iconsContainerRef.current) {
                // FIX: Cast child to Element to ensure getBoundingClientRect is available.
                const positions = Array.from(iconsContainerRef.current.children).map(child => (child as Element).getBoundingClientRect());
                setIconPositions(positions);
            }
        };

        // Initial calculation might be tricky due to rendering, so we delay it slightly
        const timeoutId = setTimeout(updatePositions, 100);

        window.addEventListener('resize', updatePositions);
        return () => {
            clearTimeout(timeoutId);
            window.removeEventListener('resize', updatePositions);
        };
    }, [desktopApps.length]); // Re-calculate if the number of apps changes


  return (
    <div className="w-full h-full bg-black relative">
        {/* Background Layer */}
        <div className="absolute inset-0 w-full h-full z-0">
            {currentWallpaper?.type === 'video' ? (
                <video
                    key={currentWallpaper.url}
                    src={currentWallpaper.url}
                    autoPlay
                    loop
                    muted
                    playsInline
                    className="w-full h-full object-cover"
                />
            ) : (
                <div
                    className="w-full h-full bg-cover bg-center transition-all duration-500"
                    style={{ backgroundImage: `url(${wallpaperUrl})` }}
                />
            )}
        </div>

        {/* Widgets Layer */}
        <div className="absolute inset-0 w-full h-full z-1 pointer-events-none">
             <Suspense fallback={null}>
                {activeWidgets.map(widget => {
                    const storeItem = STORE_ITEMS.find(item => item.id === widget.itemId);
                    if (!storeItem) return null;
                    const WidgetComponent = storeItem.component;
                    
                    // Check if the component needs icon positions
                    const needsPositions = ['pet_dog_sniffing', 'pet_hamster_sleeping'].includes(storeItem.id);

                    return (
                        <WidgetComponent 
                            key={widget.instanceId} 
                            widgetId={widget.instanceId} 
                            initialPosition={widget.position}
                            {...(needsPositions && { iconPositions: iconPositions })}
                        />
                    );
                })}
             </Suspense>
        </div>

        {/* Icons Layer */}
        <div ref={iconsContainerRef} className="relative p-4 grid grid-cols-5 gap-4 content-start z-10">
            {desktopApps.map((app) => (
            <DesktopIcon key={app.id} app={app} />
            ))}
        </div>
    </div>
  );
};

export default Desktop;