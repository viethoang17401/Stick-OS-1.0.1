import React, { useState, useEffect } from 'react';
import { useSettings } from '../hooks/useSettings';
import { User, LogIn } from 'lucide-react';
import { playSound, SOUNDS } from '../services/audioService';

interface LockScreenProps {
  onLogin: () => void;
}

const LockScreen: React.FC<LockScreenProps> = ({ onLogin }) => {
  const [time, setTime] = useState(new Date());
  const [screenState, setScreenState] = useState<'locked' | 'prompt'>('locked');
  const { wallpaperUrl, username, avatarUrl } = useSettings();

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && screenState === 'locked') {
        e.preventDefault();
        setScreenState('prompt');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [screenState]);
  
  const handleLogin = () => {
    playSound(SOUNDS.login);
    onLogin();
  };

  const formattedTime = time.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Ho_Chi_Minh' });
  const formattedDate = time.toLocaleDateString('vi-VN', { weekday: 'long', month: 'long', day: 'numeric', timeZone: 'Asia/Ho_Chi_Minh' });

  return (
    <div
      className="w-full h-full bg-cover bg-center transition-all duration-500 flex flex-col items-center justify-center text-white"
      style={{ backgroundImage: `url(${wallpaperUrl})` }}
    >
      <div className="absolute inset-0 bg-black/30 backdrop-blur-sm"></div>
      
      <div className="z-10 text-center transition-all duration-700 ease-in-out" style={{ transform: screenState === 'prompt' ? 'translateY(-150px)' : 'translateY(0px)' }}>
        <h1 className="text-8xl font-bold" style={{ textShadow: '0 0 15px rgba(0,0,0,0.5)' }}>
          {formattedTime}
        </h1>
        <p className="text-2xl mt-2" style={{ textShadow: '0 0 10px rgba(0,0,0,0.5)' }}>
          {formattedDate}
        </p>
      </div>

      <div className="z-10 absolute bottom-0 left-0 right-0 p-12 transition-opacity duration-700 ease-in-out">
        {screenState === 'locked' && (
          <div className="text-center animate-pulse">
            <p className="text-lg">Nhấn phím Space để tiếp tục</p>
          </div>
        )}

        {screenState === 'prompt' && (
          <div className="flex flex-col items-center animate-fade-in-up" style={{ animationDelay: '200ms' }}>
             <div className="relative group cursor-pointer mb-4">
                {avatarUrl ? 
                    <img src={avatarUrl} alt="Avatar" className="w-24 h-24 rounded-full object-cover shadow-2xl"/> :
                    <div className="w-24 h-24 rounded-full bg-slate-600/50 flex items-center justify-center shadow-2xl">
                        <User size={64} />
                    </div>
                }
            </div>
            <p className="text-3xl font-semibold mb-6" style={{ textShadow: '0 0 10px rgba(0,0,0,0.5)' }}>{username}</p>
            <button
              onClick={handleLogin}
              style={{ backgroundColor: 'var(--accent-color-light)'}}
              className="flex items-center justify-center gap-3 w-full max-w-xs backdrop-blur-md hover:brightness-125 text-white font-semibold py-3 px-4 rounded-lg transition-all transform hover:scale-105 border border-white/20"
            >
              <LogIn size={20} />
              <span>Đăng nhập</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default LockScreen;
