import React, { useState, useEffect, useRef } from 'react';
import { useSettings } from '../../hooks/useSettings';

interface DesktopPetProps {
    widgetId: string;
    initialPosition: { x: number; y: number };
}

const PET_SIZE = 48; // Size of the pet
const SPEED = 0.5; // Pixels per frame

const DesktopPetWalking: React.FC<DesktopPetProps> = ({ widgetId, initialPosition }) => {
    const [position, setPosition] = useState(initialPosition);
    const [direction, setDirection] = useState({ x: Math.random() > 0.5 ? 1 : -1, y: 0 });
    const [isFlipped, setIsFlipped] = useState(direction.x < 0);
    const { removeWidget } = useSettings();
    // FIX: Initialize useRef with null to provide an initial value.
    const animationFrameRef = useRef<number | null>(null);

    useEffect(() => {
        const move = () => {
            setPosition(prevPos => {
                let newX = prevPos.x + direction.x * SPEED;
                let newY = prevPos.y; // For now, only horizontal movement
                let newDirX = direction.x;
                let newDirY = direction.y;

                // Bounce off horizontal walls
                if (newX <= 0) {
                    newX = 0;
                    newDirX = 1;
                } else if (newX >= window.innerWidth - PET_SIZE) {
                    newX = window.innerWidth - PET_SIZE;
                    newDirX = -1;
                }
                
                // Update direction if it changed
                if (newDirX !== direction.x || newDirY !== direction.y) {
                    setDirection({ x: newDirX, y: newDirY });
                    setIsFlipped(newDirX < 0);
                }

                return { x: newX, y: newY };
            });

            animationFrameRef.current = requestAnimationFrame(move);
        };

        animationFrameRef.current = requestAnimationFrame(move);

        return () => {
            if (animationFrameRef.current) {
                cancelAnimationFrame(animationFrameRef.current);
            }
        };
    }, [direction]);
    
    // Allow right-click to remove the pet
    const handleContextMenu = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (window.confirm('Bạn có muốn cất thú cưng này đi không?')) {
            removeWidget(widgetId);
        }
    };


    return (
        <div
            className="absolute text-4xl select-none z-10 pointer-events-auto"
            style={{
                left: `${position.x}px`,
                bottom: `50px`, // Walk along the top of the taskbar/dock area
                width: `${PET_SIZE}px`,
                height: `${PET_SIZE}px`,
                transform: `scaleX(${isFlipped ? -1 : 1})`,
                transition: 'transform 0.2s'
            }}
            onContextMenu={handleContextMenu}
            title="Chuột phải để cất đi"
        >
            <span>🚶</span>
        </div>
    );
};

export default DesktopPetWalking;