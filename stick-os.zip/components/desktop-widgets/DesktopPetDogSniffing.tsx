import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useSettings } from '../../hooks/useSettings';

interface DesktopPetProps {
    widgetId: string;
    initialPosition: { x: number; y: number };
    iconPositions?: DOMRect[];
}

const PET_SIZE = 48;
const SPEED = 0.8;

type PetState = 'wandering' | 'movingToTarget' | 'sniffing';

const DesktopPetDogSniffing: React.FC<DesktopPetProps> = ({ widgetId, initialPosition, iconPositions }) => {
    const [position, setPosition] = useState(initialPosition);
    const [state, setState] = useState<PetState>('wandering');
    const [target, setTarget] = useState<{ x: number, y: number } | null>(null);
    const [emoji, setEmoji] = useState('🐕');
    const [isFlipped, setIsFlipped] = useState(false);
    const { removeWidget } = useSettings();
    // FIX: Initialize useRefs with null to provide an initial value.
    const animationFrameRef = useRef<number | null>(null);
    const stateTimeoutRef = useRef<number | null>(null);

    // State transition logic
    useEffect(() => {
        if (stateTimeoutRef.current) clearTimeout(stateTimeoutRef.current);

        if (state === 'wandering') {
            setEmoji('🐕');
            const wanderTime = 5000 + Math.random() * 5000; // Wander for 5-10 seconds
            stateTimeoutRef.current = window.setTimeout(() => {
                if (iconPositions && iconPositions.length > 0) {
                    const randomIcon = iconPositions[Math.floor(Math.random() * iconPositions.length)];
                    setTarget({ x: randomIcon.left + randomIcon.width / 2, y: randomIcon.top + randomIcon.height / 2 });
                    setState('movingToTarget');
                }
            }, wanderTime);
        } else if (state === 'sniffing') {
            setEmoji('🐶');
            const sniffTime = 3000 + Math.random() * 2000; // Sniff for 3-5 seconds
            stateTimeoutRef.current = window.setTimeout(() => {
                setTarget(null);
                setState('wandering');
            }, sniffTime);
        }

        return () => {
            if (stateTimeoutRef.current) clearTimeout(stateTimeoutRef.current);
        };
    }, [state, iconPositions]);

    const move = useCallback(() => {
        let currentTarget = target;
        if (state === 'wandering' && !currentTarget) {
             // Create a random target on screen to wander towards
            currentTarget = {
                x: Math.random() * (window.innerWidth - PET_SIZE),
                y: Math.random() * (window.innerHeight - PET_SIZE - 50) // Avoid taskbar area
            };
            setTarget(currentTarget);
        }

        if (currentTarget) {
            setPosition(prevPos => {
                const dx = currentTarget!.x - prevPos.x;
                const dy = currentTarget!.y - prevPos.y;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < 5) { // Reached target
                    if (state === 'movingToTarget') {
                        setState('sniffing');
                    } else if (state === 'wandering') {
                        setTarget(null); // Get a new wander target next frame
                    }
                    return prevPos;
                }

                const newX = prevPos.x + (dx / distance) * SPEED;
                const newY = prevPos.y + (dy / distance) * SPEED;

                setIsFlipped(dx < 0);

                return { x: newX, y: newY };
            });
        }
        
        animationFrameRef.current = requestAnimationFrame(move);
    }, [state, target]);

    useEffect(() => {
        animationFrameRef.current = requestAnimationFrame(move);
        return () => {
            if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
        };
    }, [move]);

    const handleContextMenu = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (window.confirm('Bạn có muốn cất Chó LU đi không?')) {
            removeWidget(widgetId);
        }
    };

    return (
        <div
            className="absolute text-4xl select-none z-10 pointer-events-auto"
            style={{
                left: `${position.x}px`,
                top: `${position.y}px`,
                width: `${PET_SIZE}px`,
                height: `${PET_SIZE}px`,
                transform: `scaleX(${isFlipped ? -1 : 1})`,
                transition: 'transform 0.2s'
            }}
            onContextMenu={handleContextMenu}
            title="Chuột phải để cất đi"
        >
            <span>{emoji}</span>
        </div>
    );
};

export default DesktopPetDogSniffing;