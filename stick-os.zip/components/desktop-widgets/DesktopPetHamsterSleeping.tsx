import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useSettings } from '../../hooks/useSettings';

interface DesktopPetProps {
    widgetId: string;
    initialPosition: { x: number; y: number };
    iconPositions?: DOMRect[];
}

const PET_SIZE = 40;
const SPEED = 0.6;

type PetState = 'wandering' | 'movingToTarget' | 'sleeping';

const DesktopPetHamsterSleeping: React.FC<DesktopPetProps> = ({ widgetId, initialPosition, iconPositions }) => {
    const [position, setPosition] = useState(initialPosition);
    const [state, setState] = useState<PetState>('wandering');
    const [target, setTarget] = useState<{ x: number, y: number } | null>(null);
    const [emoji, setEmoji] = useState('🐹');
    const [isFlipped, setIsFlipped] = useState(false);
    const { removeWidget } = useSettings();
    // FIX: Initialize useRefs with null to provide an initial value.
    const animationFrameRef = useRef<number | null>(null);
    const stateTimeoutRef = useRef<number | null>(null);

    // State transition logic
    useEffect(() => {
        if (stateTimeoutRef.current) clearTimeout(stateTimeoutRef.current);

        if (state === 'wandering') {
            setEmoji('🐹');
            const wanderTime = 4000 + Math.random() * 4000; // Wander for 4-8 seconds
            stateTimeoutRef.current = window.setTimeout(() => {
                if (iconPositions && iconPositions.length > 0) {
                    const randomIcon = iconPositions[Math.floor(Math.random() * iconPositions.length)];
                    // Target the top-center of the icon
                    setTarget({ x: randomIcon.left + (randomIcon.width / 2) - (PET_SIZE / 2), y: randomIcon.top - PET_SIZE });
                    setState('movingToTarget');
                }
            }, wanderTime);
        } else if (state === 'sleeping') {
            setEmoji('😴');
            const sleepTime = 10000 + Math.random() * 10000; // Sleep for 10-20 seconds
            stateTimeoutRef.current = window.setTimeout(() => {
                setTarget(null);
                setState('wandering');
            }, sleepTime);
        }

        return () => {
            if (stateTimeoutRef.current) clearTimeout(stateTimeoutRef.current);
        };
    }, [state, iconPositions]);

    const move = useCallback(() => {
        let currentTarget = target;
        if (state === 'wandering' && !currentTarget) {
             // Create a random target on screen to wander towards
            currentTarget = {
                x: Math.random() * (window.innerWidth - PET_SIZE),
                y: Math.random() * (window.innerHeight - PET_SIZE - 50)
            };
            setTarget(currentTarget);
        }

        if (currentTarget) {
            setPosition(prevPos => {
                const dx = currentTarget!.x - prevPos.x;
                const dy = currentTarget!.y - prevPos.y;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < 5) {
                    if (state === 'movingToTarget') {
                        setState('sleeping');
                    } else if (state === 'wandering') {
                        setTarget(null);
                    }
                    return { x: currentTarget!.x, y: currentTarget!.y }; // Snap to final position
                }

                const newX = prevPos.x + (dx / distance) * SPEED;
                const newY = prevPos.y + (dy / distance) * SPEED;
                setIsFlipped(dx < 0);
                return { x: newX, y: newY };
            });
        }
        
        animationFrameRef.current = requestAnimationFrame(move);
    }, [state, target]);

    useEffect(() => {
        animationFrameRef.current = requestAnimationFrame(move);
        return () => {
            if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
        };
    }, [move]);
    
    const handleContextMenu = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (window.confirm('Bạn có muốn đánh thức Chụt Chụt và cất đi không?')) {
            removeWidget(widgetId);
        }
    };

    return (
        <div
            className="absolute text-3xl select-none z-10 pointer-events-auto"
            style={{
                left: `${position.x}px`,
                top: `${position.y}px`,
                width: `${PET_SIZE}px`,
                height: `${PET_SIZE}px`,
                transform: `scaleX(${isFlipped ? -1 : 1})`,
                transition: 'top 0.1s linear, left 0.1s linear, transform 0.2s'
            }}
            onContextMenu={handleContextMenu}
            title="Chuột phải để cất đi"
        >
            <span>{emoji}</span>
        </div>
    );
};

export default DesktopPetHamsterSleeping;