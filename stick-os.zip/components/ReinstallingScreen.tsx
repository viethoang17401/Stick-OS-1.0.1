import React, { useState, useEffect } from 'react';

interface ReinstallingScreenProps {
    onComplete: () => void;
}

const ReinstallingScreen: React.FC<ReinstallingScreenProps> = ({ onComplete }) => {
    const [progress, setProgress] = useState(0);
    const [statusText, setStatusText] = useState('Bắt đầu quá trình cài đặt...');

    useEffect(() => {
        const interval = setInterval(() => {
            setProgress(prev => {
                const next = prev + Math.random() * 5;
                if (next >= 100) {
                    clearInterval(interval);
                    setStatusText('Cài đặt hoàn tất. Đang khởi động lại...');
                    setTimeout(onComplete, 1500); // Wait a bit before completing
                    return 100;
                }
                
                if (next > 75) setStatusText('Hoàn tất các tinh chỉnh cuối cùng...');
                else if (next > 40) setStatusText('Cài đặt các tính năng và ứng dụng...');
                else if (next > 10) setStatusText('Sao chép tập tin hệ thống...');

                return next;
            });
        }, 200);

        return () => clearInterval(interval);
    }, [onComplete]);

    return (
        <div className="w-screen h-screen bg-black text-white font-mono flex flex-col items-center justify-center p-8">
            <h1 className="text-3xl mb-4">Đang cài đặt Stick OS</h1>
            <p className="text-lg mb-8">Máy tính của bạn sẽ khởi động lại sau giây lát.</p>
            
            <div className="w-full max-w-xl bg-gray-700 rounded-full h-4 mb-4">
                <div className="bg-blue-500 h-4 rounded-full" style={{ width: `${progress}%`, transition: 'width 0.2s ease-in-out' }}></div>
            </div>

            <p className="text-md mb-2">{Math.round(progress)}%</p>
            <p className="text-sm text-gray-400">{statusText}</p>
        </div>
    );
};

export default ReinstallingScreen;
