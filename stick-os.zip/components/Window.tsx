import React, { useState, useRef, useCallback, Suspense, useEffect } from 'react';
import { Minus, Square, X, Maximize } from 'lucide-react';
import type { WindowState, AppDefinition } from '../types';
import { useWindows } from '../hooks/useWindows';

interface WindowProps {
  windowState: WindowState;
  app: AppDefinition;
}

const Window: React.FC<WindowProps> = ({ windowState, app }) => {
  const {
    closeWindow,
    focusWindow,
    toggleMinimize,
    toggleMaximize,
    updateWindowPosition,
    updateWindowSize,
  } = useWindows();
  
  const [isClosing, setIsClosing] = useState(false);
  const windowRef = useRef<HTMLDivElement>(null);

  // Using a ref for the state to avoid stale closures in event listeners
  const stateRef = useRef(windowState);
  useEffect(() => {
    stateRef.current = windowState;
  }, [windowState]);

  // Refs for drag/resize state to avoid re-renders and for direct DOM manipulation
  const dragInfo = useRef({
    isDragging: false,
    isResizing: false,
    offsetX: 0,
    offsetY: 0,
  });

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!windowRef.current) return;

    // Direct DOM manipulation for performance
    if (dragInfo.current.isDragging && !stateRef.current.isMaximized) {
      const newX = e.clientX - dragInfo.current.offsetX;
      const newY = e.clientY - dragInfo.current.offsetY;
      windowRef.current.style.left = `${newX}px`;
      windowRef.current.style.top = `${newY}px`;
    }
    if (dragInfo.current.isResizing) {
        const currentPosition = stateRef.current.position;
        const newWidth = e.clientX - currentPosition.x;
        const newHeight = e.clientY - currentPosition.y;
        windowRef.current.style.width = `${Math.max(300, newWidth)}px`;
        windowRef.current.style.height = `${Math.max(200, newHeight)}px`;
    }
  }, []);

  const handleMouseUp = useCallback(() => {
    // When mouse is released, update the React state with the final position/size
    if (windowRef.current && (dragInfo.current.isDragging || dragInfo.current.isResizing)) {
      const rect = windowRef.current.getBoundingClientRect();
      
      if (dragInfo.current.isDragging) {
        updateWindowPosition(stateRef.current.id, { x: rect.left, y: rect.top });
      }
      
      if (dragInfo.current.isResizing) {
        updateWindowSize(stateRef.current.id, { width: rect.width, height: rect.height });
      }
    }
    
    // Reset drag/resize state and remove global listeners
    dragInfo.current.isDragging = false;
    dragInfo.current.isResizing = false;
    
    window.removeEventListener('mousemove', handleMouseMove);
    window.removeEventListener('mouseup', handleMouseUp);
  }, [updateWindowPosition, updateWindowSize, handleMouseMove]);

  const handleMouseDownDrag = (e: React.MouseEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest('.window-control') || stateRef.current.isMaximized) return;
    
    focusWindow(stateRef.current.id);
    dragInfo.current.isDragging = true;
    
    const rect = windowRef.current!.getBoundingClientRect();
    dragInfo.current.offsetX = e.clientX - rect.left;
    dragInfo.current.offsetY = e.clientY - rect.top;
    
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  const handleMouseDownResize = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    focusWindow(stateRef.current.id);
    dragInfo.current.isResizing = true;
    
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  // Cleanup listeners on unmount
  useEffect(() => {
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    }
  }, [handleMouseMove, handleMouseUp]);
  
  const handleClose = () => {
    setIsClosing(true);
    setTimeout(() => {
      closeWindow(windowState.id);
    }, 200); // Duration must match animation duration
  };
  
  const baseWindowStyle: React.CSSProperties = {
    zIndex: windowState.zIndex,
    backgroundColor: 'var(--window-bg)',
    borderColor: 'var(--border-color)',
    color: 'var(--text-primary)',
    boxShadow: windowState.isFocused 
      ? `0 0 25px var(--focus-ring-color)`
      : `0 10px 25px -5px rgba(0, 0, 0, 0.3)`,
  };

  const maximizedStyle: React.CSSProperties = {
    top: 0,
    left: 0,
    width: '100vw',
    height: 'calc(100vh - 48px)', // Account for taskbar
    borderRadius: 0,
  };

  const normalStyle: React.CSSProperties = {
    top: `${windowState.position.y}px`,
    left: `${windowState.position.x}px`,
    width: `${windowState.size.width}px`,
    height: `${windowState.size.height}px`,
  };

  const windowStyle: React.CSSProperties = {
      ...baseWindowStyle,
      ...(windowState.isMaximized ? maximizedStyle : normalStyle)
  };

  const windowBaseClass = 'absolute flex flex-col rounded-lg overflow-hidden transition-all duration-200 ease-in-out border backdrop-blur-md';
  const stateClass = windowState.isMinimized ? 'opacity-0 scale-90 pointer-events-none' : 'opacity-100 scale-100';
  const animationClass = isClosing ? 'animate-window-close' : 'animate-window-open';
  
  const className = `${windowBaseClass} ${stateClass} ${animationClass}`;

  return (
    <div
      ref={windowRef}
      className={className}
      style={windowStyle}
      onMouseDown={() => focusWindow(windowState.id)}
    >
      <header
        className="flex items-center justify-between h-8 px-2 select-none"
        style={{ backgroundColor: 'var(--header-bg)'}}
        onMouseDown={handleMouseDownDrag}
        onDoubleClick={() => toggleMaximize(windowState.id)}
      >
        <div className="flex items-center gap-2">
          {React.cloneElement(app.icon, { className: "w-4 h-4" })}
          <span className="text-sm font-medium">{app.name}</span>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => toggleMinimize(windowState.id)} className="window-control p-1 rounded hover:bg-white/20 transition-colors"><Minus size={14} /></button>
          <button onClick={() => toggleMaximize(windowState.id)} className="window-control p-1 rounded hover:bg-white/20 transition-colors">
            {windowState.isMaximized ? <Maximize size={14} /> : <Square size={14} />}
          </button>
          <button onClick={handleClose} className="window-control p-1 rounded hover:bg-red-500 transition-colors"><X size={14} /></button>
        </div>
      </header>
      <main className="flex-grow p-1 overflow-auto" style={{ backgroundColor: 'var(--secondary-bg)'}}>
        <Suspense fallback={<div className="flex items-center justify-center h-full">Đang tải ứng dụng...</div>}>
          <app.component onClose={handleClose} />
        </Suspense>
      </main>
      {!windowState.isMaximized && (
        <div 
          className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize"
          onMouseDown={handleMouseDownResize}
        />
      )}
    </div>
  );
};

export default Window;
