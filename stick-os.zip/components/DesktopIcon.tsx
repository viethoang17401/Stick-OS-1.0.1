
import React from 'react';
import type { AppDefinition } from '../types';
import { useWindows } from '../hooks/useWindows';
import { useSystem } from '../hooks/useSystem';

interface DesktopIconProps {
  app: AppDefinition;
}

const DesktopIcon: React.FC<DesktopIconProps> = ({ app }) => {
  const { openWindow } = useWindows();
  const { triggerSystemCrash } = useSystem();

  const handleDoubleClick = () => {
    if (app.id === 'uia-virus') {
      triggerSystemCrash();
    } else {
      openWindow(app.id);
    }
  };

  return (
    <div
      className="flex flex-col items-center justify-center text-center w-24 h-24 p-2 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
      onDoubleClick={handleDoubleClick}
    >
      {React.cloneElement(app.icon, { className: "w-10 h-10" })}
      <span className="text-white text-sm mt-2 select-none truncate w-full">{app.name}</span>
    </div>
  );
};

export default DesktopIcon;