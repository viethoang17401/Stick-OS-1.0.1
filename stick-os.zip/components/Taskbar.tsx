import React, { useState, useEffect } from 'react';
import { APPS } from '../constants';
import { useWindows } from '../hooks/useWindows';
import { useSettings } from '../hooks/useSettings';
import { User, LayoutGrid } from 'lucide-react'; // Changed Power to LayoutGrid
import StartMenu from './StartMenu'; // Import StartMenu

interface TaskbarProps {
  onLogout: () => void;
}

const Taskbar: React.FC<TaskbarProps> = ({ onLogout }) => {
  const [time, setTime] = useState(new Date());
  const [isStartMenuOpen, setIsStartMenuOpen] = useState(false); // New state for Start Menu
  const { windows, focusWindow, toggleMinimize } = useWindows();
  const { username, avatarUrl } = useSettings();

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleTaskbarIconClick = (windowId: string) => {
    const win = windows.find(w => w.id === windowId);
    if(win) {
        if(win.isFocused && !win.isMinimized) {
            toggleMinimize(win.id);
        } else {
            focusWindow(win.id);
        }
    }
  }

  // The power dialog logic is now in StartMenu.tsx

  return (
    <>
      <StartMenu isOpen={isStartMenuOpen} onClose={() => setIsStartMenuOpen(false)} onLogout={onLogout} />
      <div 
        className="absolute bottom-0 left-0 right-0 h-12 backdrop-blur-lg flex items-center justify-between px-4 z-[99999] border-t"
        style={{ 
          backgroundColor: 'var(--primary-bg)',
          borderColor: 'var(--border-color)',
          color: 'var(--text-primary)'
        }}
      >
        <div className="flex items-center gap-2">
          <button
            id="start-button" // Added ID for click-outside logic
            onClick={() => setIsStartMenuOpen(prev => !prev)}
            className={`p-2 rounded transition-colors ${isStartMenuOpen ? 'bg-[var(--accent-color-light)]' : 'hover:bg-[var(--accent-color-light)]'} cursor-pointer`}
            aria-label="Start Menu"
            title="Start Menu"
          >
              <LayoutGrid className="w-6 h-6 text-white" />
          </button>
          {/* Pinned/Running Apps */}
          <div className="flex items-center gap-1">
            {windows.map(win => {
              const app = APPS.find(a => a.id === win.appId);
              if (!app) return null;
              
              const isAppFocused = win.isFocused && !win.isMinimized;
              const style = isAppFocused ? { backgroundColor: 'var(--accent-color-light)' } : {};

              return (
                <button 
                  key={win.id}
                  onClick={() => handleTaskbarIconClick(win.id)}
                  className={`p-2 rounded-md transition-colors relative hover:bg-white/10`}
                  style={style}
                  title={app.name}
                >
                  {React.cloneElement(app.icon, { className: "w-6 h-6" })}
                  <div 
                    className={`absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-1 rounded-full`}
                    style={{ backgroundColor: win.isMinimized ? 'var(--text-secondary)' : 'var(--accent-color)' }}
                  ></div>
                </button>
              )
            })}
          </div>
        </div>
        <div className="flex items-center gap-4 text-white text-sm font-medium">
            <div className="flex items-center gap-2">
                {avatarUrl ? 
                    <img src={avatarUrl} alt="User Avatar" className="w-6 h-6 rounded-full object-cover" /> :
                    <div className="w-6 h-6 rounded-full bg-gray-600 flex items-center justify-center">
                        <User size={14}/>
                    </div>
                }
                <span>{username}</span>
            </div>
            <div>
              <span>{time.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Ho_Chi_Minh' })}</span>
              <span className="mx-2">|</span>
              <span>{time.toLocaleDateString('vi-VN', { month: 'short', day: 'numeric', timeZone: 'Asia/Ho_Chi_Minh' })}</span>
            </div>
        </div>
      </div>
      {/* Power dialog removed from here */}
    </>
  );
};

export default Taskbar;