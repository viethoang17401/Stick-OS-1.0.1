import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';

interface AnnoyingAdProps {
  message: string;
  onClose: () => void;
}

const AnnoyingAd: React.FC<AnnoyingAdProps> = ({ message, onClose }) => {
    const [position, setPosition] = useState({ top: 'auto', bottom: 'auto', left: 'auto', right: 'auto' });

    useEffect(() => {
        // Randomly position the ad in one of the corners
        // FIX: Ensure each corner object has all properties to match the state's type.
        const corners = [
            { top: 'auto', bottom: '6rem', left: 'auto', right: '1rem' }, // Bottom right
            { top: 'auto', bottom: '6rem', left: '1rem', right: 'auto' },  // Bottom left
            { top: '1rem', bottom: 'auto', left: 'auto', right: '1rem' },    // Top right
        ];
        setPosition(corners[Math.floor(Math.random() * corners.length)]);
    }, []);

    return (
        <div
            className="absolute z-[99990] w-64 bg-gradient-to-r from-yellow-400 to-orange-500 text-black p-3 rounded-lg shadow-2xl border-2 border-black animate-fade-in-up"
            style={{ ...position }}
        >
            <div className="flex justify-between items-start">
                <div>
                    <h3 className="font-bold text-lg">Stick Fun™</h3>
                    <p className="text-sm mt-1">{message}</p>
                </div>
                <button onClick={onClose} className="p-1 rounded-full hover:bg-black/20 -mt-1 -mr-1">
                    <X size={16} />
                </button>
            </div>
        </div>
    );
};

export default AnnoyingAd;