import React from 'react';
import { Folder, FileText, Gamepad2, Film, Music, Image as ImageIcon, Code } from 'lucide-react';

export interface FSItem {
  name: string;
  type: 'folder' | 'file';
  icon?: React.ReactNode;
  children?: FSItem[];
  size?: string;
}

export const VIRTUAL_FILE_SYSTEM: Record<string, FSItem[]> = {
  'C:': [
    { name: 'Program Files', type: 'folder', children: [
      { name: 'StickOS', type: 'folder', children: [
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        { name: 'stickos.exe', type: 'file', icon: React.createElement(Code, { size: 32 }), size: '1.2MB' },
        { name: 'uninstall.exe', type: 'file', size: '500KB' },
      ]},
      { name: 'GameOn', type: 'folder', children: [
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        { name: 'gameon.exe', type: 'file', icon: React.createElement(Gamepad2, { size: 32 }), size: '2.5MB' },
      ]},
    ], size: '3.7MB' },
    { name: 'Users', type: 'folder', children: [
      { name: 'Hoang Nguoi Que', type: 'folder', children: [
        { name: 'Desktop', type: 'folder', size: '10MB' },
        { name: 'Documents', type: 'folder', children: [
            { name: 'kế_hoạch_troll_botu.txt', type: 'file', size: '2KB' },
        ], size: '2KB' },
        { name: 'Downloads', type: 'folder', size: '150MB' },
        { name: 'Pictures', type: 'folder', children: [
            // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
            { name: 'botu_ngu.png', type: 'file', icon: React.createElement(ImageIcon, { size: 32 }), size: '1.2MB' },
        ], size: '1.2MB' },
      ], size: '161.2MB' },
    ], size: '161.2MB' },
    { name: 'Windows', type: 'folder', children: [
        { name: 'System32', type: 'folder', size: '1.5GB' },
    ], size: '1.5GB' },
    { name: 'system.log', type: 'file', size: '12KB' },
  ],
  'D:': [
    { name: 'Games', type: 'folder', children: [
        { name: 'Stick Runner', type: 'folder', size: '250MB' },
        { name: 'FreeFireHTML5', type: 'folder', size: '120MB' },
    ], size: '370MB' },
    { name: 'Work', type: 'folder', children: [
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        { name: 'StickOS_Source', type: 'folder', icon: React.createElement(Code, { size: 32 }), size: '50MB' },
    ], size: '50MB' },
    { name: 'backup_2024.zip', type: 'file', size: '2.1GB' },
  ],
  'E:': [
    { name: 'Movies', type: 'folder', children: [
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        { name: 'Stickman Story Ep1.mp4', type: 'file', icon: React.createElement(Film, { size: 32 }), size: '700MB' },
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        { name: 'Animator vs Animation.mp4', type: 'file', icon: React.createElement(Film, { size: 32 }), size: '300MB' },
    ], size: '1GB' },
    { name: 'Music', type: 'folder', children: [
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        { name: 'lofi_chill.mp3', type: 'file', icon: React.createElement(Music, { size: 32 }), size: '5MB' },
    ], size: '5MB' },
    { name: 'Photos', type: 'folder', children: [
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        { name: 'AI_chan_wallpaper.jpg', type: 'file', icon: React.createElement(ImageIcon, { size: 32 }), size: '2MB' },
        // FIX: Replaced JSX with React.createElement to be valid in a .ts file.
        { name: 'haibara_wallpaper.png', type: 'file', icon: React.createElement(ImageIcon, { size: 32 }), size: '3MB' },
    ], size: '5MB' },
  ]
};

// Helper function to get items at a specific path
export const getItemsFromPath = (path: string[]): FSItem[] | null => {
    if (path.length === 0) return null;

    const drive = path[0];
    let currentLevel: FSItem[] | undefined = VIRTUAL_FILE_SYSTEM[drive];

    if (!currentLevel) return null;

    for (let i = 1; i < path.length; i++) {
        const folderName = path[i];
        const folder = currentLevel?.find(item => item.name === folderName && item.type === 'folder');
        if (folder && folder.children) {
            currentLevel = folder.children;
        } else {
            return null; // Path is invalid
        }
    }

    return currentLevel || [];
};