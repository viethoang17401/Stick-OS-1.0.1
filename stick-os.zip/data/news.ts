// FIX: The AccountTier type should be imported from '../types' where it is defined, not from the hook that uses it.
import type { AccountTier } from '../types';

export type NewsCategory = 'Stick Man Story' | 'Stick OS' | 'Game' | 'Meme' | 'Kỹ thuật' | 'Tin bí mật';

export interface NewsArticle {
  id: number;
  title: string;
  category: NewsCategory;
  content: string;
  breaking?: boolean;
  minTier: AccountTier;
}

export const newsData: NewsArticle[] = [
  {
    id: 1,
    title: 'Botu lại vô tình đạp nát máy quay!',
    category: 'Stick OS',
    content: 'Trong bản cập nhật mới nhất, nút "Tự Hủy" đã được phóng to 200% và chuyển sang màu đỏ neon cho dễ bấm hơn. "Chúng tôi lắng nghe người dùng," đội phát triển cho biết. Thiệt hại ước tính -20 củ.',
    minTier: 'Free',
  },
  {
    id: 2,
    title: 'Trailer Fanmade Gây Bão Cộng Đồng',
    category: 'Stick Man Story',
    content: 'Một fan hâm mộ vừa tung ra trailer tự làm cho phần tiếp theo của Stick Man Story, và nó... đỉnh hơn cả bản gốc! Hoàng đang xem xét việc thuê fan này.',
    minTier: 'Free',
  },
  {
    id: 3,
    title: 'AI-chan Bị Phát Hiện Cài Auto-Correct Troll',
    category: 'Stick Man Story',
    content: 'Nguồn tin nội bộ cho hay, AI-chan đã bí mật thay đổi từ "Xin chào" thành "Yo bro" trong kịch bản của Kila. Vụ việc đang được điều tra.',
    minTier: 'Free',
  },
  {
    id: 4,
    title: 'Báo Cáo Server: "CPU 900%, RAM Đang Khóc"',
    category: 'Stick OS',
    content: 'Server ảo của chúng ta đang hoạt động hết công suất. Một kỹ thuật viên cho biết anh thấy RAM đang rưng rưng nước mắt. Chúng tôi đã đưa cho nó một chiếc khăn giấy.',
    minTier: 'Free',
  },
  {
    id: 5,
    title: 'Sự Kiện Cuối Tuần Stick Runner!',
    category: 'Game',
    content: 'Tuần này, bất kỳ ai chạy được 2000m trong Stick Runner sẽ nhận được một theme mới độc quyền: "Chuối Trượt Vỏ". Chúc may mắn!',
    minTier: 'Pro',
  },
  {
    id: 6,
    title: 'Người Chơi Đạt High-score Mới Trong Stick Clicker',
    category: 'Game',
    content: 'Chúc mừng người chơi "ClickMaster69" đã đạt 1 triệu điểm click. Bàn tay của anh ấy giờ có lẽ đã trở thành một với con chuột.',
    minTier: 'Pro',
  },
  {
    id: 7,
    title: 'Bộ sưu tập Meme Botu phá hoại',
    category: 'Meme',
    content: 'Một bức ảnh chụp lại cảnh Botu đang "vô tình" ngồi lên chiếc laptop mới của Hoàng đã được lan truyền. Hoàng từ chối bình luận. Kèm theo là 10 meme mới nhất từ cộng đồng.',
    minTier: 'Free',
  },
  {
    id: 8,
    title: 'Quote Bất Hủ Tuần Này',
    category: 'Meme',
    content: '"Tại sao cậu lại đối xử với tôi như vậy?" - Màn hình xanh said.',
    minTier: 'Free',
  },
  {
    id: 9,
    title: 'Mẹo: Cách "tiết kiệm pin" cho PC',
    category: 'Kỹ thuật',
    content: 'Để tiết kiệm pin cho Stick OS Online, chỉ cần... tắt màn hình. Đúng vậy, nó hoạt động 100%. Đừng hỏi tại sao.',
    minTier: 'Free',
  },
  {
    id: 10,
    title: 'Cách Unlock Theme Bí Mật',
    category: 'Kỹ thuật',
    content: 'Chỉ dành cho Super ULLTRA: Gõ "matrix" vào màn hình desktop để mở khóa theme Hacker. Đừng nói cho ai biết nhé!🤫',
    minTier: 'Super ULLTRA',
  },
  {
    id: 11,
    title: 'SPOILER ALERT: Trùm Cuối Lộ Diện?',
    category: 'Tin bí mật',
    content: 'Rò rỉ lớn nhất từ trước đến nay: Nhân vật phản diện chính trong phần 2 của Stick Man Story sẽ là... một con mèo tên là "Meow-gnus". Meow-gnus có khả năng hack mọi thiết bị điện tử và cực kỳ ghét con trỏ chuột.',
    minTier: 'Super ULLTRA',
  },
  {
    id: 12,
    title: 'Bug khiến StickVideo không chạy? Đã sửa!',
    category: 'Stick OS',
    content: 'Lỗi khiến ứng dụng StickVideo mở ra nhưng chỉ hiện màn hình đen đã được khắc phục. Nguyên nhân là do Botu dùng đĩa video làm lót ly cà phê.',
    minTier: 'Free',
  },
  {
    id: 13,
    title: '🏆 Kỷ lục mới: "Chiến Thần Gamer" đạt 2,000,000m trong Người Que Chạy!',
    category: 'Game',
    content: 'Một kỷ lục mới đã được thiết lập! Người chơi có nickname "Chiến Thần Gamer" vừa phá vỡ mọi giới hạn với quãng đường chạy đáng kinh ngạc là 2,000,000 mét. Cộng đồng game thủ đang xôn xao, và có tin đồn rằng ngón tay của anh ấy giờ đây có thể bẻ cong cả thìa.',
    breaking: true,
    minTier: 'Pro',
  },
];
