import React from 'react';

export interface AppDefinition {
  id: string;
  name: string;
  // FIX: Changed icon type to React.ReactElement<any> to be compatible with React.cloneElement, allowing props like `className` to be passed.
  icon: React.ReactElement<any>;
  component: React.ComponentType<any>; // Allow props like onClose
  defaultSize: { width: number; height: number };
}

export interface WindowState {
  id: string;
  appId: string;
  position: { x: number; y: number };
  size: { width: number; height: number };
  zIndex: number;
  isMinimized: boolean;
  isMaximized: boolean;
  isFocused: boolean;
}

export type AccountTier = 'Free' | 'Pro' | 'VIP' | 'ULLTRA' | 'Super ULLTRA';

export interface ThemeColors {
  '--primary-bg': string;
  '--secondary-bg': string;
  '--window-bg': string;
  '--header-bg': string;
  '--accent-color': string;
  '--accent-color-light': string;
  '--text-primary': string;
  '--text-secondary': string;
  '--border-color': string;
  '--focus-ring-color': string;
}

export interface ThemeDefinition {
  id: string;
  name: string;
  tier: AccountTier;
  colors: ThemeColors;
}

export interface StoreItem {
    id: string;
    name: string;
    description: string;
    price: number;
    tier: AccountTier;
    // The component that will be rendered on the desktop
    component: React.ComponentType<{ 
        widgetId: string, 
        initialPosition: { x: number, y: number },
        iconPositions?: DOMRect[] // Add optional prop for interactive pets
    }>;
}

export interface DesktopWidgetInstance {
    instanceId: string; // Unique ID for this specific instance of the widget
    itemId: string; // ID of the item from the store
    position: { x: number, y: number };
}