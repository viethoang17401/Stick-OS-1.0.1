
import React, { createContext, useContext, useState, ReactNode } from 'react';

type SystemState = 'ok' | 'glitching' | 'bsod' | 'reinstalling';

interface SystemContextType {
  systemState: SystemState;
  triggerSystemCrash: () => void;
  startReinstall: () => void;
}

const SystemContext = createContext<SystemContextType | undefined>(undefined);

export const SystemProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [systemState, setSystemState] = useState<SystemState>('ok');

  const triggerSystemCrash = () => {
    setSystemState('glitching');
    setTimeout(() => {
        setSystemState('bsod');
    }, 2500); // Glitch for 2.5 seconds before BSOD
  };

  const startReinstall = () => {
    setSystemState('reinstalling');
  };

  const value = { systemState, triggerSystemCrash, startReinstall };

  return (
    <SystemContext.Provider value={value}>
      {children}
    </SystemContext.Provider>
  );
};

export const useSystem = (): SystemContextType => {
  const context = useContext(SystemContext);
  if (!context) {
    throw new Error('useSystem must be used within a SystemProvider');
  }
  return context;
};