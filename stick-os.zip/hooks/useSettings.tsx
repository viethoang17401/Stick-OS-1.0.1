import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { WALLPAPER_URL, THEMES, STORE_ITEMS } from '../constants';
import type { AccountTier, ThemeDefinition, ThemeColors, DesktopWidgetInstance } from '../types';

interface SettingsContextType {
  accountLevel: AccountTier;
  setAccountLevel: (level: AccountTier) => void;
  wallpaperUrl: string;
  setWallpaperUrl: (url: string) => void;
  uploadWallpaper: (file: File) => void;
  username: string;
  setUsername: (name: string) => void;
  avatarUrl: string;
  uploadAvatar: (file: File) => void;
  themeId: string;
  setThemeId: (id: string) => void;
  getCurrentTheme: () => ThemeDefinition;
  customThemeColors: ThemeColors | null;
  updateCustomTheme: (newColors: ThemeColors) => void;
  resetCustomTheme: () => void;
  stickoins: number;
  purchasedItemIds: string[];
  buyItem: (itemId: string) => boolean;
  activeWidgets: DesktopWidgetInstance[];
  addWidget: (itemId: string) => void;
  removeWidget: (instanceId: string) => void;
  lastClaimTimestamp: number;
  claimCoins: () => boolean;
  hasAdBlocker: boolean;
  purchaseAdBlocker: () => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

const TIER_REWARDS: Record<AccountTier, { amount: number, cooldown: number }> = {
  'Free': { amount: 100, cooldown: 60 * 1000 },
  'Pro': { amount: 200, cooldown: 30 * 1000 },
  'VIP': { amount: 500, cooldown: 15 * 1000 },
  'ULLTRA': { amount: 1000, cooldown: 10 * 1000 },
  'Super ULLTRA': { amount: 5000, cooldown: 5 * 1000 },
};

// Helper function to resize and compress image
const resizeImage = (file: File, maxWidth: number, maxHeight: number, quality: number): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      if (!event.target?.result) return reject(new Error("Failed to read file"));
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let { width, height } = img;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          return reject(new Error('Could not get canvas context'));
        }
        ctx.drawImage(img, 0, 0, width, height);
        // Use JPEG for compression, which is better for photos often used as wallpapers/avatars
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = (err) => reject(err);
      img.src = event.target.result as string;
    };
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
};


export const SettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [accountLevel, setAccountLevelState] = useState<AccountTier>(() => {
    return (localStorage.getItem('stickos-account-level') as AccountTier) || 'Free';
  });
  const [wallpaperUrl, setWallpaperUrlState] = useState<string>(() => {
    return localStorage.getItem('stickos-wallpaper-url') || WALLPAPER_URL;
  });
  const [username, setUsernameState] = useState<string>(() => {
    return localStorage.getItem('stickos-username') || 'Admin';
  });
  const [avatarUrl, setAvatarUrlState] = useState<string>(() => {
    return localStorage.getItem('stickos-avatar-url') || '';
  });
  const [themeId, setThemeIdState] = useState<string>(() => {
    return localStorage.getItem('stickos-theme-id') || 'default';
  });
  const [customThemeColors, setCustomThemeColorsState] = useState<ThemeColors | null>(() => {
    try {
        const saved = localStorage.getItem('stickos-custom-theme');
        return saved ? JSON.parse(saved) : null;
    } catch (e) {
        console.error("Failed to parse custom theme from localStorage", e);
        return null;
    }
  });

  // Store state
  const [stickoins, setStickoinsState] = useState<number>(() => {
      const saved = localStorage.getItem('stickos-stickoins');
      return saved ? parseInt(saved, 10) : 500;
  });
  const [purchasedItemIds, setPurchasedItemIdsState] = useState<string[]>(() => {
      const saved = localStorage.getItem('stickos-purchased-items');
      return saved ? JSON.parse(saved) : [];
  });
  const [activeWidgets, setActiveWidgetsState] = useState<DesktopWidgetInstance[]>(() => {
      const saved = localStorage.getItem('stickos-active-widgets');
      return saved ? JSON.parse(saved) : [];
  });
  const [lastClaimTimestamp, setLastClaimTimestampState] = useState<number>(() => {
      const saved = localStorage.getItem('stickos-last-claim-timestamp');
      return saved ? parseInt(saved, 10) : 0;
  });
  const [hasAdBlocker, setHasAdBlockerState] = useState<boolean>(() => {
    return localStorage.getItem('stickos-has-adblocker') === 'true';
  });


  useEffect(() => {
    try {
        localStorage.setItem('stickos-account-level', accountLevel);
    } catch (e) {
        console.error("Failed to save account level to localStorage:", e);
    }
  }, [accountLevel]);
  
  useEffect(() => {
    try {
        localStorage.setItem('stickos-wallpaper-url', wallpaperUrl);
    } catch (e) {
        console.error("Failed to save wallpaper to localStorage:", e);
        alert('Lưu hình nền thất bại! Hình ảnh có thể quá lớn và sẽ không được lưu sau khi tải lại trang.');
    }
  }, [wallpaperUrl]);

  useEffect(() => {
    try {
        localStorage.setItem('stickos-username', username);
    } catch (e) {
        console.error("Failed to save username to localStorage:", e);
    }
  }, [username]);

  useEffect(() => {
    try {
        localStorage.setItem('stickos-avatar-url', avatarUrl);
    } catch (e) {
        console.error("Failed to save avatar to localStorage:", e);
        alert('Lưu ảnh đại diện thất bại! Hình ảnh có thể quá lớn và sẽ không được lưu sau khi tải lại trang.');
    }
  }, [avatarUrl]);

  useEffect(() => {
    try {
        localStorage.setItem('stickos-theme-id', themeId);
    } catch (e) {
        console.error("Failed to save theme to localStorage:", e);
    }
  }, [themeId]);

  // Store state persistence
    useEffect(() => {
        localStorage.setItem('stickos-stickoins', stickoins.toString());
    }, [stickoins]);
    useEffect(() => {
        localStorage.setItem('stickos-purchased-items', JSON.stringify(purchasedItemIds));
    }, [purchasedItemIds]);
    useEffect(() => {
        localStorage.setItem('stickos-active-widgets', JSON.stringify(activeWidgets));
    }, [activeWidgets]);
    useEffect(() => {
        localStorage.setItem('stickos-last-claim-timestamp', lastClaimTimestamp.toString());
    }, [lastClaimTimestamp]);
     useEffect(() => {
        localStorage.setItem('stickos-has-adblocker', String(hasAdBlocker));
    }, [hasAdBlocker]);


  const setAccountLevel = (level: AccountTier) => {
    setAccountLevelState(level);
  };
  
  const setWallpaperUrl = (url: string) => {
    setWallpaperUrlState(url);
  };
  
  const setUsername = (name: string) => {
    setUsernameState(name);
  }
  
  const setThemeId = (id: string) => {
    setThemeIdState(id);
  }
  
  const updateCustomTheme = (newColors: ThemeColors) => {
    setCustomThemeColorsState(newColors);
    try {
        localStorage.setItem('stickos-custom-theme', JSON.stringify(newColors));
    } catch(e) {
        console.error("Failed to save custom theme", e);
    }
  };

  const resetCustomTheme = () => {
      setCustomThemeColorsState(null);
      localStorage.removeItem('stickos-custom-theme');
      if (themeId === 'custom') {
          setThemeIdState('default'); // Fallback to default
      }
  };
  
  const getCurrentTheme = useCallback((): ThemeDefinition => {
      if (themeId === 'custom' && customThemeColors) {
          return {
              id: 'custom',
              name: 'Giao diện Tùy chỉnh',
              tier: 'VIP',
              colors: customThemeColors
          };
      }
      return THEMES.find(theme => theme.id === themeId) || THEMES[0];
  }, [themeId, customThemeColors]);

  const uploadWallpaper = useCallback(async (file: File) => {
    if (!file.type.startsWith('image/')) {
        alert('Vui lòng chọn một tệp hình ảnh.');
        return;
    }
    try {
      // Resize to a common screen width and compress as JPEG
      const resizedDataUrl = await resizeImage(file, 1920, 1080, 0.85);
      setWallpaperUrlState(resizedDataUrl);
    } catch (error) {
      console.error("Failed to resize wallpaper:", error);
      alert('Đã xảy ra lỗi khi xử lý hình ảnh. Vui lòng thử lại.');
    }
  }, []);
  
  const uploadAvatar = useCallback(async (file: File) => {
    if (!file.type.startsWith('image/')) {
        alert('Vui lòng chọn một tệp hình ảnh.');
        return;
    }
    try {
      // Resize to a reasonable avatar size and compress
      const resizedDataUrl = await resizeImage(file, 256, 256, 0.9);
      setAvatarUrlState(resizedDataUrl);
    } catch (error) {
      console.error("Failed to resize avatar:", error);
      alert('Đã xảy ra lỗi khi xử lý hình ảnh. Vui lòng thử lại.');
    }
  }, []);

  const buyItem = (itemId: string): boolean => {
    const item = STORE_ITEMS.find(i => i.id === itemId);
    if (!item) {
        alert("Vật phẩm không tồn tại!");
        return false;
    }
    if (stickoins < item.price) {
        alert("Bạn không đủ Stickoins!");
        return false;
    }
    if (purchasedItemIds.includes(itemId)) {
        alert("Bạn đã sở hữu vật phẩm này rồi!");
        return false;
    }

    setStickoinsState(prev => prev - item.price);
    setPurchasedItemIdsState(prev => [...prev, itemId]);
    alert(`Mua thành công ${item.name}!`);
    return true;
  };

  const addWidget = (itemId: string) => {
    const newWidget: DesktopWidgetInstance = {
        instanceId: `widget-${Date.now()}`,
        itemId: itemId,
        position: {
            x: Math.random() * (window.innerWidth - 100),
            y: Math.random() * (window.innerHeight - 100)
        }
    };
    setActiveWidgetsState(prev => [...prev, newWidget]);
  };
  
  const removeWidget = (instanceId: string) => {
      setActiveWidgetsState(prev => prev.filter(w => w.instanceId !== instanceId));
  };

  const claimCoins = (): boolean => {
      const now = Date.now();
      const tierInfo = TIER_REWARDS[accountLevel];
      const timeSinceLastClaim = now - lastClaimTimestamp;
      
      if (timeSinceLastClaim >= tierInfo.cooldown) {
          setStickoinsState(prev => prev + tierInfo.amount);
          setLastClaimTimestampState(now);
          alert(`Bạn đã nhận được ${tierInfo.amount} Stickoins!`);
          return true;
      } else {
          const timeLeft = Math.ceil((tierInfo.cooldown - timeSinceLastClaim) / 1000);
          alert(`Bạn cần chờ ${timeLeft} giây nữa để nhận lại!`);
          return false;
      }
  };

  const purchaseAdBlocker = () => {
    const cost = 80;
    if (hasAdBlocker) {
        alert("Bạn đã có trình chặn quảng cáo rồi!");
        return;
    }
    if (stickoins < cost) {
        alert(`Không đủ Stickoins! Cần ${cost} coin.`);
        return;
    }
    setStickoinsState(prev => prev - cost);
    setHasAdBlockerState(true);
    alert("Đã mua trình chặn quảng cáo! Tận hưởng sự yên bình.");
  };


  const value = { accountLevel, setAccountLevel, wallpaperUrl, setWallpaperUrl, uploadWallpaper, username, setUsername, avatarUrl, uploadAvatar, themeId, setThemeId, getCurrentTheme, customThemeColors, updateCustomTheme, resetCustomTheme, stickoins, purchasedItemIds, buyItem, activeWidgets, addWidget, removeWidget, lastClaimTimestamp, claimCoins, hasAdBlocker, purchaseAdBlocker };

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = (): SettingsContextType => {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};