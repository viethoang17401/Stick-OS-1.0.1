
import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import type { WindowState } from '../types';
import { APPS } from '../constants';

interface WindowsContextType {
  windows: WindowState[];
  openWindow: (appId: string) => void;
  closeWindow: (id: string) => void;
  focusWindow: (id: string) => void;
  toggleMinimize: (id: string) => void;
  toggleMaximize: (id: string) => void;
  updateWindowPosition: (id: string, position: { x: number; y: number }) => void;
  updateWindowSize: (id: string, size: { width: number; height: number }) => void;
  windowsHidden: boolean;
  toggleHideAllWindows: () => void;
}

const WindowsContext = createContext<WindowsContextType | undefined>(undefined);

export const WindowsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [windows, setWindows] = useState<WindowState[]>([]);
  const [maxZIndex, setMaxZIndex] = useState(100);
  const [windowsHidden, setWindowsHidden] = useState(false);

  const openWindow = useCallback((appId: string) => {
    const app = APPS.find(a => a.id === appId);
    if (!app) return;

    const newWindowId = `${appId}-${Date.now()}`;
    const newZ = maxZIndex + 1;
    setMaxZIndex(newZ);

    setWindows(currentWindows => [
      ...currentWindows.map(w => ({ ...w, isFocused: false })),
      {
        id: newWindowId,
        appId,
        position: { x: 150 + (currentWindows.length % 10) * 30, y: 100 + (currentWindows.length % 10) * 30 },
        size: app.defaultSize,
        zIndex: newZ,
        isMinimized: false,
        isMaximized: false,
        isFocused: true,
      },
    ]);
  }, [maxZIndex]);

  const closeWindow = useCallback((id: string) => {
    setWindows(currentWindows => currentWindows.filter(w => w.id !== id));
  }, []);

  const focusWindow = useCallback((id: string) => {
    const newZ = maxZIndex + 1;
    setMaxZIndex(newZ);
    setWindows(currentWindows =>
      currentWindows.map(w =>
        w.id === id ? { ...w, zIndex: newZ, isFocused: true, isMinimized: false } : { ...w, isFocused: false }
      )
    );
  }, [maxZIndex]);

  const toggleMinimize = useCallback((id: string) => {
    setWindows(currentWindows =>
      currentWindows.map(w =>
        w.id === id ? { ...w, isMinimized: !w.isMinimized, isFocused: !w.isMinimized } : { ...w, isFocused: w.id === id ? true : false }
      )
    );
  }, []);

  const toggleMaximize = useCallback((id: string) => {
    setWindows(currentWindows =>
      currentWindows.map(w =>
        w.id === id ? { ...w, isMaximized: !w.isMaximized } : w
      )
    );
  }, []);

  const updateWindowPosition = useCallback((id: string, position: { x: number; y: number }) => {
    setWindows(currentWindows =>
      currentWindows.map(w => (w.id === id ? { ...w, position } : w))
    );
  }, []);
  
  const updateWindowSize = useCallback((id: string, size: { width: number; height: number }) => {
    setWindows(currentWindows =>
      currentWindows.map(w => (w.id === id ? { ...w, size } : w))
    );
  }, []);

  const toggleHideAllWindows = useCallback(() => {
    setWindowsHidden(prev => !prev);
  }, []);

  const value = { windows, openWindow, closeWindow, focusWindow, toggleMinimize, toggleMaximize, updateWindowPosition, updateWindowSize, windowsHidden, toggleHideAllWindows };

  return (
    <WindowsContext.Provider value={value}>
      {children}
    </WindowsContext.Provider>
  );
};

export const useWindows = (): WindowsContextType => {
  const context = useContext(WindowsContext);
  if (!context) {
    throw new Error('useWindows must be used within a WindowsProvider');
  }
  return context;
};
