import React from 'react';
import { APPS } from '../constants';
import { useWindows } from '../hooks/useWindows';

const GameOn = () => {
  const { openWindow } = useWindows();
  const games = APPS.filter(app => ['stickrunner', 'stickclicker', 'stickmemory', 'stickjump', 'botubomb', 'freefirehtml5', 'phorestaurant'].includes(app.id));

  return (
    <div className="w-full h-full bg-indigo-900 text-white p-4 overflow-y-auto">
      <h1 className="text-3xl font-bold text-center mb-6 text-yellow-300" style={{ textShadow: '2px 2px #000' }}>TRUNG TÂM GAME</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {games.map(game => (
          <div 
            key={game.id} 
            className="bg-indigo-700 aspect-square rounded-lg flex flex-col items-center justify-center text-center p-2 font-semibold cursor-pointer hover:bg-indigo-600 hover:scale-105 transition-transform"
            onClick={() => openWindow(game.id)}
          >
            {React.cloneElement(game.icon, { className: "w-12 h-12 mb-2" })}
            <span>{game.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GameOn;