import React, { useState } from 'react';

const videoData = [
  {
    id: 'p9Lz_c31b-M',
    title: 'Stick War 1: Cuộc chiến bút chì',
    channel: 'Zhu Z.',
    thumbnail: 'https://i.ytimg.com/vi/p9Lz_c31b-M/hqdefault.jpg',
  },
  {
    id: 'npTC6b5-yvM',
    title: 'Animator vs. Animation (Bản gốc)',
    channel: 'Alan Becker',
    thumbnail: 'https://i.ytimg.com/vi/npTC6b5-yvM/hqdefault.jpg',
  },
  {
    id: '_z2cBNm10-A',
    title: 'Đại chiến Người Que Siêu cấp',
    channel: 'Hyun\'s Dojo',
    thumbnail: 'https://i.ytimg.com/vi/_z2cBNm10-A/hqdefault.jpg',
  },
  {
    id: 'sB47p1PE5sQ',
    title: 'Căn phòng Tử thần',
    channel: 'elemental727',
    thumbnail: 'https://i.ytimg.com/vi/sB47p1PE5sQ/hqdefault.jpg',
  },
  {
    id: 'c59nAyprgK4',
    title: 'Người Que "phê pha"',
    channel: 'hotdiggedydemon',
    thumbnail: 'https://i.ytimg.com/vi/c59nAyprgK4/hqdefault.jpg',
  },
];


const StickVideo = () => {
  const [currentVideo, setCurrentVideo] = useState(videoData[0]);

  return (
    <div className="w-full h-full bg-gray-900 text-white flex flex-col p-4 gap-4">
      <div className="flex-grow bg-black rounded-lg flex items-center justify-center flex-col overflow-hidden">
        <iframe
          key={currentVideo.id}
          className="w-full h-full"
          src={`https://www.youtube.com/embed/${currentVideo.id}?autoplay=1`}
          title={currentVideo.title}
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        ></iframe>
      </div>
      <div className="h-1/3 overflow-y-auto">
        <h2 className="text-lg font-bold mb-2">Xem tiếp</h2>
        {videoData.map((video) => (
          <div 
            key={video.id} 
            className="flex items-center gap-4 p-2 rounded-lg hover:bg-gray-800 cursor-pointer"
            onClick={() => setCurrentVideo(video)}
          >
            <img src={video.thumbnail} alt={video.title} className="w-24 h-16 object-cover bg-gray-700 rounded-md" />
            <div>
              <p className="font-semibold text-sm">{video.title}</p>
              <p className="text-xs text-gray-400">{video.channel}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StickVideo;