import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Play, RotateCcw } from 'lucide-react';
import { playSound, SOUNDS } from '../../services/audioService';

const GAME_AREA_WIDTH = 368;
const GAME_AREA_HEIGHT = 300;
const BOMB_SIZE = 40;

interface Bomb {
    id: number;
    x: number;
    y: number;
}

const BotuBomb = () => {
    const [gameState, setGameState] = useState<'idle' | 'playing' | 'over'>('idle');
    const [score, setScore] = useState(0);
    const [lives, setLives] = useState(3);
    const [bombs, setBombs] = useState<Bomb[]>([]);
    
    // Fix: Use `number` for browser timer IDs instead of `NodeJS.Timeout`.
    const bombTimers = useRef<Map<number, number>>(new Map());

    const addBomb = useCallback(() => {
        const newBomb: Bomb = {
            id: Date.now(),
            x: Math.random() * (GAME_AREA_WIDTH - BOMB_SIZE),
            y: Math.random() * (GAME_AREA_HEIGHT - BOMB_SIZE)
        };
        setBombs(prev => [...prev, newBomb]);

        const timer = setTimeout(() => {
            playSound(SOUNDS.explode, 0.5);
            setBombs(prev => prev.filter(b => b.id !== newBomb.id));
            setLives(prev => prev - 1);
            bombTimers.current.delete(newBomb.id);
        }, 1500 - Math.min(score * 5, 1000)); // Bombs get faster as score increases

        bombTimers.current.set(newBomb.id, timer);
    }, [score]);

    useEffect(() => {
        // Fix: Use `number` for browser timer IDs instead of `NodeJS.Timeout`.
        let gameInterval: number | null = null;
        if (gameState === 'playing') {
            gameInterval = setInterval(addBomb, 1000 - Math.min(score * 10, 800));
        }
        return () => {
            if (gameInterval) clearInterval(gameInterval);
        };
    }, [gameState, addBomb, score]);

    useEffect(() => {
        if (lives <= 0) {
            setGameState('over');
            // Clear all remaining bombs and timers
            bombs.forEach(bomb => clearTimeout(bombTimers.current.get(bomb.id)));
            bombTimers.current.clear();
            setBombs([]);
        }
    }, [lives, bombs]);

    const handleBombClick = (bombId: number) => {
        playSound(SOUNDS.defuse);
        clearTimeout(bombTimers.current.get(bombId));
        bombTimers.current.delete(bombId);
        setBombs(prev => prev.filter(b => b.id !== bombId));
        setScore(prev => prev + 10);
    };

    const startGame = () => {
        setScore(0);
        setLives(3);
        setBombs([]);
        bombTimers.current.forEach(timer => clearTimeout(timer));
        bombTimers.current.clear();
        setGameState('playing');
    };

    return (
        <div className="w-full h-full bg-gray-900 text-white flex flex-col items-center justify-between p-4 text-center font-mono select-none">
            <div className="w-full">
                <h1 className="text-3xl font-bold text-rose-500">Bom Botu</h1>
                <div className="flex justify-around text-xl">
                    <p>Điểm: <span className="text-yellow-300">{score}</span></p>
                    <p>Mạng: <span className="text-red-500">{'❤️'.repeat(lives)}</span></p>
                </div>
            </div>

            <div className="relative bg-gray-800 border-2 border-rose-500" style={{ width: GAME_AREA_WIDTH, height: GAME_AREA_HEIGHT }}>
                {gameState !== 'playing' && (
                    <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center z-10">
                        {gameState === 'idle' && <p className="text-2xl">Nhấn Bắt đầu</p>}
                        {gameState === 'over' && (
                            <>
                                <p className="text-3xl text-red-500">Hết giờ!</p>
                                <p className="text-xl mt-2">Điểm cuối: {score}</p>
                            </>
                        )}
                    </div>
                )}
                {bombs.map(bomb => (
                    <div
                        key={bomb.id}
                        onClick={() => handleBombClick(bomb.id)}
                        className="absolute text-3xl cursor-pointer animate-ping"
                        style={{ left: bomb.x, top: bomb.y, width: BOMB_SIZE, height: BOMB_SIZE }}
                    >
                        💣
                    </div>
                ))}
            </div>

            <div className="flex gap-4 mt-2">
                {gameState !== 'playing' ? (
                    <button onClick={startGame} className="flex items-center gap-2 bg-green-600 px-4 py-2 rounded hover:bg-green-700">
                        <Play size={16} /> {gameState === 'idle' ? 'Bắt đầu' : 'Chơi lại'}
                    </button>
                ) : (
                    <p className="h-10">Phá bom!</p> // Placeholder to prevent layout shift
                )}
            </div>
        </div>
    );
};

export default BotuBomb;
