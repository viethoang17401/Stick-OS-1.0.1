import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Play, RotateCcw } from 'lucide-react';
import { playSound, SOUNDS } from '../../services/audioService';

// Game constants
const GAME_WIDTH = 384; // Corresponds to Tailwind's w-96
const GAME_HEIGHT = 400;
const PLAYER_WIDTH = 20;
const PLAYER_HEIGHT = 40;
const GRAVITY = 0.6;
const JUMP_FORCE = -12;
const OBSTACLE_WIDTH = 20;
const OBSTACLE_HEIGHT = 30;
const OBSTACLE_SPEED = 4;

const StickRunner = () => {
    const [gameState, setGameState] = useState<'idle' | 'playing' | 'over'>('idle');
    const [score, setScore] = useState(0);
    
    const playerY = useRef(GAME_HEIGHT - PLAYER_HEIGHT);
    const playerVelocity = useRef(0);
    const obstacles = useRef<{ x: number; y: number }[]>([]);
    const frameCount = useRef(0);
    // FIX: Initialize useRef with null to provide an initial value.
    const gameLoopRef = useRef<number | null>(null);
    
    const gameLoop = useCallback(() => {
        // Update player position (gravity)
        playerVelocity.current += GRAVITY;
        playerY.current += playerVelocity.current;
        
        // Ground check
        if (playerY.current > GAME_HEIGHT - PLAYER_HEIGHT) {
            playerY.current = GAME_HEIGHT - PLAYER_HEIGHT;
            playerVelocity.current = 0;
        }

        // Update obstacle positions
        obstacles.current = obstacles.current.map(obs => ({ ...obs, x: obs.x - OBSTACLE_SPEED })).filter(obs => obs.x > -OBSTACLE_WIDTH);

        // Spawn new obstacles
        frameCount.current++;
        if (frameCount.current % 90 === 0) { // Spawn every 1.5 seconds approx.
            obstacles.current.push({ x: GAME_WIDTH, y: GAME_HEIGHT - OBSTACLE_HEIGHT });
        }
        
        // Collision check
        const playerRect = { x: 50, y: playerY.current, width: PLAYER_WIDTH, height: PLAYER_HEIGHT };
        for (const obs of obstacles.current) {
            const obsRect = { x: obs.x, y: obs.y, width: OBSTACLE_WIDTH, height: OBSTACLE_HEIGHT };
            if (
                playerRect.x < obsRect.x + obsRect.width &&
                playerRect.x + playerRect.width > obsRect.x &&
                playerRect.y < obsRect.y + obsRect.height &&
                playerRect.y + playerRect.height > obsRect.y
            ) {
                setGameState('over');
                return;
            }
        }

        // Update score
        setScore(prev => prev + 1);

        gameLoopRef.current = requestAnimationFrame(gameLoop);
    }, []);

    useEffect(() => {
        if (gameState === 'playing') {
            gameLoopRef.current = requestAnimationFrame(gameLoop);
        } else {
            if(gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
            if (gameState === 'over') {
                playSound(SOUNDS.gameOver);
            }
        }
        return () => {
            if(gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
        }
    }, [gameState, gameLoop]);
    
    const startGame = () => {
        setScore(0);
        playerY.current = GAME_HEIGHT - PLAYER_HEIGHT;
        playerVelocity.current = 0;
        obstacles.current = [];
        frameCount.current = 0;
        setGameState('playing');
    };
    
    const handleJump = () => {
        if (gameState === 'playing' && playerY.current >= GAME_HEIGHT - PLAYER_HEIGHT - 1) { // Only jump from ground
            playSound(SOUNDS.jump);
            playerVelocity.current = JUMP_FORCE;
        } else if (gameState === 'idle' || gameState === 'over') {
            startGame();
        }
    };

    return (
        <div className="w-full h-full bg-gray-900 text-white flex flex-col items-center justify-center p-4 text-center font-mono select-none">
            <h1 className="text-3xl font-bold mb-4 text-cyan-400">Người Que Chạy</h1>
            <p className="text-xl mb-4">Quãng đường: <span className="text-yellow-300">{score}m</span></p>

            <div 
                className="w-96 h-[400px] bg-gray-800 border-2 border-cyan-400 relative overflow-hidden cursor-pointer"
                onClick={handleJump}
            >
                {gameState === 'idle' && (
                    <div className="w-full h-full flex flex-col items-center justify-center">
                        <p className="text-2xl">Nhấn để Bắt đầu</p>
                        <Play size={48} className="mt-4"/>
                    </div>
                )}

                {gameState === 'over' && (
                     <div className="w-full h-full flex flex-col items-center justify-center bg-black/50">
                        <p className="text-3xl text-red-500">Game Over</p>
                        <p className="text-xl mt-2">Quãng đường cuối cùng: {score}m</p>
                        <p className="text-lg mt-4">Nhấn để Chơi lại</p>
                        <RotateCcw size={32} className="mt-4" />
                    </div>
                )}
                
                {/* Render game objects only when playing to prevent visual glitches on state change */}
                {gameState === 'playing' && (
                    <>
                        {/* Player */}
                        <div 
                            className="absolute bg-white text-black flex items-center justify-center" 
                            style={{ 
                                left: 50, 
                                top: playerY.current, 
                                width: PLAYER_WIDTH, 
                                height: PLAYER_HEIGHT 
                            }}
                        >🏃</div>

                        {/* Obstacles */}
                        {obstacles.current.map((obs, i) => (
                             <div 
                                key={i} 
                                className="absolute bg-red-500" 
                                style={{ 
                                    left: obs.x, 
                                    top: obs.y, 
                                    width: OBSTACLE_WIDTH, 
                                    height: OBSTACLE_HEIGHT 
                                }}
                            />
                        ))}
                    </>
                )}
            </div>
        </div>
    );
};

export default StickRunner;