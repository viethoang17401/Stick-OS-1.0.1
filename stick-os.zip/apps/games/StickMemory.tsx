import React, { useState, useEffect } from 'react';
import { RotateCcw } from 'lucide-react';
import { playSound, SOUNDS } from '../../services/audioService';

const EMOJIS = ['🧠', '💻', '🚀', '🔥', '🕹️', '👽', '🤖', '👾'];

const createShuffledDeck = () => {
  const deck = [...EMOJIS, ...EMOJIS];
  // Simple Fisher-Yates shuffle
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
};


const StickMemory = () => {
    const [cards, setCards] = useState(createShuffledDeck());
    const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
    const [solvedPairs, setSolvedPairs] = useState<string[]>([]);
    const [moves, setMoves] = useState(0);
    const [isChecking, setIsChecking] = useState(false);
    const [isGameOver, setIsGameOver] = useState(false);

    useEffect(() => {
        if (flippedIndices.length === 2) {
            setIsChecking(true);
            const [firstIndex, secondIndex] = flippedIndices;
            if (cards[firstIndex] === cards[secondIndex]) {
                playSound(SOUNDS.match);
                setSolvedPairs(prev => [...prev, cards[firstIndex]]);
                setFlippedIndices([]);
                setIsChecking(false);
            } else {
                setTimeout(() => {
                    setFlippedIndices([]);
                    setIsChecking(false);
                }, 1000);
            }
            setMoves(prev => prev + 1);
        }
    }, [flippedIndices, cards]);
    
    useEffect(() => {
        if (solvedPairs.length === EMOJIS.length) {
            playSound(SOUNDS.win);
            setIsGameOver(true);
        }
    }, [solvedPairs]);

    const handleCardClick = (index: number) => {
        if (isChecking || flippedIndices.includes(index) || solvedPairs.includes(cards[index]) || flippedIndices.length >= 2) {
            return;
        }
        playSound(SOUNDS.flip);
        setFlippedIndices(prev => [...prev, index]);
    };

    const resetGame = () => {
        setCards(createShuffledDeck());
        setFlippedIndices([]);
        setSolvedPairs([]);
        setMoves(0);
        setIsChecking(false);
        setIsGameOver(false);
    };

    return (
        <div className="w-full h-full bg-gray-900 text-white flex flex-col items-center justify-center p-4 text-center font-mono select-none">
            <h1 className="text-3xl font-bold mb-2 text-lime-400">Trí Nhớ Người Que</h1>
            {isGameOver ? (
                <div className="flex flex-col items-center justify-center">
                    <p className="text-2xl text-yellow-300 mb-4">Bạn đã thắng!</p>
                    <p className="text-lg">Tổng số lần lật: {moves}</p>
                </div>
            ) : (
                <>
                    <p className="mb-4">Số lần lật: {moves}</p>
                    <div className="grid grid-cols-4 gap-2 mb-4">
                        {cards.map((card, index) => {
                            const isFlipped = flippedIndices.includes(index);
                            const isSolved = solvedPairs.includes(card);
                            return (
                                <div 
                                    key={index}
                                    onClick={() => handleCardClick(index)}
                                    className={`w-16 h-16 rounded-md flex items-center justify-center text-3xl cursor-pointer transition-transform duration-300`}
                                    style={{ transformStyle: 'preserve-3d', transform: (isFlipped || isSolved) ? 'rotateY(180deg)' : '' }}
                                >
                                    <div className="absolute w-full h-full bg-lime-700 rounded-md flex items-center justify-center" style={{ backfaceVisibility: 'hidden' }}>
                                        ?
                                    </div>
                                    <div className="absolute w-full h-full bg-lime-500 rounded-md flex items-center justify-center" style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}>
                                        {card}
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </>
            )}
            <div className="flex gap-4 mt-auto">
                <button onClick={resetGame} className="flex items-center gap-2 bg-red-600 px-4 py-2 rounded hover:bg-red-700">
                    <RotateCcw size={16} /> Chơi lại
                </button>
            </div>
        </div>
    );
};

export default StickMemory;
