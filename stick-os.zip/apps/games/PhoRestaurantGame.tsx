import React from 'react';
import { TriangleAlert } from 'lucide-react';

interface PhoRestaurantGameProps {
  onClose?: () => void;
}

const PhoRestaurantGame: React.FC<PhoRestaurantGameProps> = ({ onClose }) => {
  return (
    <div className="w-full h-full bg-gray-800 text-white flex flex-col items-center justify-center p-4 text-center font-sans select-none">
      <div className="w-full max-w-sm">
        <div className="flex items-center justify-center gap-3 mb-4">
          <TriangleAlert size={32} className="text-yellow-400" />
          <h1 className="text-xl font-bold text-yellow-400">Lỗi Tương Thích</h1>
        </div>
        <div className="bg-black/20 p-4 rounded-lg">
          <p className="mb-1">
            Hệ điều hành của bạn không hỗ trợ trò chơi "Tiệm Phở Anh Hai".
          </p>
          <p className="text-sm text-gray-400">
            Vui lòng sử dụng Windows 10 hoặc hệ điều hành khác để trải nghiệm.
          </p>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="mt-6 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition-all"
          >
            OK
          </button>
        )}
      </div>
    </div>
  );
};

export default PhoRestaurantGame;
