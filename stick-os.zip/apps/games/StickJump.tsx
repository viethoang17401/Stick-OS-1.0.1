import React, { useState, useEffect, useRef } from 'react';
import { Play, RotateCcw, ArrowUp } from 'lucide-react';
import { playSound, SOUNDS } from '../../services/audioService';

const StickJump = () => {
    const [gameState, setGameState] = useState<'idle' | 'charging' | 'jumping'>('idle');
    const [power, setPower] = useState(0);
    const [powerDirection, setPowerDirection] = useState<'up' | 'down'>('up');
    const [height, setHeight] = useState(0);
    const [maxHeight, setMaxHeight] = useState(0);
    // FIX: Initialize useRef with null to provide an initial value.
    const requestRef = useRef<number | null>(null);

    const updatePower = () => {
        setPower(prev => {
            let nextPower = powerDirection === 'up' ? prev + 2 : prev - 2;
            if (nextPower >= 100) {
                nextPower = 100;
                setPowerDirection('down');
            } else if (nextPower <= 0) {
                nextPower = 0;
                setPowerDirection('up');
            }
            return nextPower;
        });
        requestRef.current = requestAnimationFrame(updatePower);
    };

    useEffect(() => {
        if (gameState === 'charging') {
            requestRef.current = requestAnimationFrame(updatePower);
        } else {
            if (requestRef.current) {
                cancelAnimationFrame(requestRef.current);
            }
        }
        return () => {
            if (requestRef.current) {
                cancelAnimationFrame(requestRef.current);
            }
        };
    }, [gameState, powerDirection]);
    
    const handleAction = () => {
        if (gameState === 'idle' || gameState === 'jumping') {
            setGameState('charging');
            setHeight(0);
        } else if (gameState === 'charging') {
            const newHeight = Math.round(power * 1.5);
            playSound(SOUNDS.jump);
            setHeight(newHeight);
            setMaxHeight(prev => Math.max(prev, newHeight));
            setGameState('jumping');
        }
    };

    const handleReset = () => {
        setGameState('idle');
        setPower(0);
        setHeight(0);
        setMaxHeight(0);
    };

  return (
    <div className="w-full h-full bg-gray-900 text-white flex flex-col items-center justify-center p-4 text-center font-mono select-none">
        <h1 className="text-3xl font-bold mb-2 text-fuchsia-400">Người Que Nhảy</h1>
        <p className="text-lg mb-1">Độ cao hiện tại: <span className="text-yellow-300">{height}m</span></p>
        <p className="text-lg mb-4">Độ cao tối đa: <span className="text-yellow-300">{maxHeight}m</span></p>

        <div className="w-64 h-64 bg-gray-800 border-2 border-fuchsia-400 flex flex-col justify-end items-center p-4 relative">
             <div className={`absolute bottom-4 text-5xl transition-transform duration-500 ease-out`} style={{ transform: `translateY(-${height * 0.5}px)` }}>🧗</div>
             {gameState === 'jumping' && <p className="text-xl animate-ping text-green-400">+{height}m</p>}
        </div>

        <div className="w-64 h-6 bg-gray-700 my-4 rounded">
            <div className="h-full bg-gradient-to-r from-green-400 to-red-500 rounded" style={{ width: `${power}%` }}></div>
        </div>

        <button onClick={handleAction} className="flex items-center gap-2 bg-green-600 px-6 py-3 rounded hover:bg-green-700 text-lg">
            <ArrowUp size={20} />
            {gameState === 'charging' ? 'NHẢY!' : 'CHUẨN BỊ'}
        </button>

        <div className="flex gap-4 mt-auto">
            <button onClick={handleReset} className="flex items-center gap-2 bg-red-600 px-4 py-2 rounded hover:bg-red-700">
                <RotateCcw size={16} /> Chơi lại
            </button>
        </div>
    </div>
  );
};

export default StickJump;