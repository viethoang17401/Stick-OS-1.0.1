import React, { useState, useCallback } from 'react';
import { RotateCcw } from 'lucide-react';
import { playSound, SOUNDS } from '../../services/audioService';

interface FloatingNumber {
    id: number;
    x: number;
    y: number;
}

const StickClicker = () => {
    const [score, setScore] = useState(0);
    const [floatingNumbers, setFloatingNumbers] = useState<FloatingNumber[]>([]);
    
    const handleClick = useCallback((e: React.MouseEvent<HTMLButtonElement>) => {
        playSound(SOUNDS.click, 0.7);
        setScore(prev => prev + 1);
        
        const rect = e.currentTarget.getBoundingClientRect();
        const newFloatingNumber: FloatingNumber = {
            id: Date.now() + Math.random(),
            x: e.clientX - rect.left,
            y: e.clientY - rect.top,
        };

        setFloatingNumbers(prev => [...prev, newFloatingNumber]);

        setTimeout(() => {
            setFloatingNumbers(prev => prev.filter(n => n.id !== newFloatingNumber.id));
        }, 1000); // Remove after 1 second (must match animation duration)

    }, []);

    const handleReset = () => {
        setScore(0);
    };

  return (
    <div className="w-full h-full bg-gray-900 text-white flex flex-col items-center justify-center p-4 text-center font-mono select-none">
        <style>{`
            @keyframes float-up {
                from {
                    transform: translateY(0);
                    opacity: 1;
                }
                to {
                    transform: translateY(-50px);
                    opacity: 0;
                }
            }
            .float-animation {
                animation: float-up 1s ease-out forwards;
            }
        `}</style>
        <h1 className="text-3xl font-bold mb-4 text-amber-400">Người Que Clicker</h1>
        <p className="text-xl mb-4">Số lần nhấp: <span className="text-yellow-300">{score}</span></p>
        
        <button 
            onClick={handleClick} 
            className="relative w-48 h-48 bg-amber-500 rounded-full text-white font-bold text-2xl flex items-center justify-center active:bg-amber-600 transform active:scale-90 transition-all focus:outline-none"
        >
            NHẤP VÀO TÔI!
            {floatingNumbers.map(num => (
                <span 
                    key={num.id} 
                    className="absolute text-2xl font-bold text-yellow-300 pointer-events-none float-animation"
                    style={{ left: `${num.x}px`, top: `${num.y}px` }}
                >
                    +1
                </span>
            ))}
        </button>

        <div className="flex gap-4 mt-auto">
            <button onClick={handleReset} className="flex items-center gap-2 bg-red-600 px-4 py-2 rounded hover:bg-red-700">
                <RotateCcw size={16} /> Chơi lại
            </button>
        </div>
    </div>
  );
};

export default StickClicker;
