import React, { useState, useEffect } from 'react';
import { playSound, SOUNDS } from '../../services/audioService';

const GAME_TIME = 30; // 30 seconds
const TARGET_SIZE = 40;
const GAME_AREA_WIDTH = 368;
const GAME_AREA_HEIGHT = 300;

interface Target {
    id: number;
    x: number;
    y: number;
}

const FreeFireHTML5 = () => {
    const [gameState, setGameState] = useState<'idle' | 'playing' | 'over'>('idle');
    const [score, setScore] = useState(0);
    const [timeLeft, setTimeLeft] = useState(GAME_TIME);
    const [targets, setTargets] = useState<Target[]>([]);
    
    // Game loop for timer and spawning targets
    useEffect(() => {
        // Fix: Use `number` for browser timer IDs instead of `NodeJS.Timeout`.
        let gameInterval: number | null = null;
        if (gameState === 'playing') {
            gameInterval = setInterval(() => {
                setTimeLeft(prev => prev - 1);
                
                // Add new target
                if (Math.random() < 0.6) { // 60% chance to spawn a target each second
                    setTargets(prev => [...prev, {
                        id: Date.now(),
                        x: Math.random() * (GAME_AREA_WIDTH - TARGET_SIZE),
                        y: Math.random() * (GAME_AREA_HEIGHT - TARGET_SIZE)
                    }]);
                }

            }, 1000);
        }
        return () => {
            if (gameInterval) clearInterval(gameInterval);
        };
    }, [gameState]);

    // End game when time is up
    useEffect(() => {
        if (timeLeft <= 0 && gameState === 'playing') {
            playSound(SOUNDS.gameOver);
            setGameState('over');
            setTargets([]);
        }
    }, [timeLeft, gameState]);

    const handleTargetClick = (targetId: number) => {
        if (gameState !== 'playing') return;
        playSound(SOUNDS.shoot);
        setScore(prev => prev + 10);
        setTargets(prev => prev.filter(t => t.id !== targetId));
    };

    const startGame = () => {
        setScore(0);
        setTimeLeft(GAME_TIME);
        setTargets([]);
        setGameState('playing');
    };

  return (
    <div className="w-full h-full bg-gray-900 text-white flex flex-col items-center justify-between p-4 text-center font-mono select-none">
        <div className="w-full">
            <h1 className="text-3xl font-bold text-orange-400">Lửa Chùa HTML5</h1>
            <div className="flex justify-around text-xl">
                <p>Điểm: <span className="text-yellow-300">{score}</span></p>
                <p>Thời gian: <span className="text-cyan-300">{timeLeft}</span></p>
            </div>
        </div>
        
        <div 
            className="relative bg-gray-800 border-2 border-orange-400 cursor-crosshair"
            style={{ width: GAME_AREA_WIDTH, height: GAME_AREA_HEIGHT }}
        >
            {gameState !== 'playing' && (
                <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center z-10">
                    {gameState === 'idle' && <p className="text-2xl">Bắt đầu tập bắn!</p>}
                    {gameState === 'over' && (
                        <>
                            <p className="text-3xl text-red-500">Hết giờ!</p>
                            <p className="text-xl mt-2">Điểm cuối: {score}</p>
                        </>
                    )}
                </div>
            )}
            {targets.map(target => (
                <div
                    key={target.id}
                    onClick={() => handleTargetClick(target.id)}
                    className="absolute text-4xl"
                    style={{ left: target.x, top: target.y, width: TARGET_SIZE, height: TARGET_SIZE }}
                >
                    🎯
                </div>
            ))}
        </div>

        <div className="flex gap-4 mt-2">
            {gameState !== 'playing' && (
                <button 
                    onClick={startGame}
                    className="bg-green-600 text-white font-bold py-2 px-6 rounded hover:bg-green-700"
                >
                    {gameState === 'idle' ? 'BẮT ĐẦU' : 'CHƠI LẠI'}
                </button>
            )}
            {gameState === 'playing' && (
                 <p className="h-10 text-gray-500">Bắn các mục tiêu!</p> // Placeholder
            )}
        </div>
    </div>
  );
};

export default FreeFireHTML5;
