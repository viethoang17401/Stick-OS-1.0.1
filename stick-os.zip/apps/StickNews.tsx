import React, { useState, useMemo, useEffect } from 'react';
import { newsData, NewsArticle, NewsCategory } from '../data/news';
import { useSettings } from '../hooks/useSettings';
import type { AccountTier } from '../types';
import { Search, Moon, Sun, Lock, ArrowLeft, Newspaper, Film, Server, Gamepad2, Smile, Wrench, Key } from 'lucide-react';

const TIER_LEVELS: Record<AccountTier, number> = {
  'Free': 0, 'Pro': 1, 'VIP': 2, 'ULLTRA': 3, 'Super ULLTRA': 4
};

const CATEGORIES: { name: NewsCategory, icon: React.ReactNode, minTier: AccountTier }[] = [
    { name: 'Stick Man Story', icon: <Film size={18} />, minTier: 'Free' },
    { name: 'Stick OS', icon: <Server size={18} />, minTier: 'Free' },
    { name: 'Game', icon: <Gamepad2 size={18} />, minTier: 'Pro' },
    { name: 'Meme', icon: <Smile size={18} />, minTier: 'Free' },
    { name: 'Kỹ thuật', icon: <Wrench size={18} />, minTier: 'Free' },
    { name: 'Tin bí mật', icon: <Key size={18} />, minTier: 'Super ULLTRA' }
];

const StickNews = () => {
  const { accountLevel } = useSettings();
  const [selectedCategory, setSelectedCategory] = useState<NewsCategory | 'Tất cả'>('Tất cả');
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  const userAccessLevel = TIER_LEVELS[accountLevel];

  useEffect(() => {
    // Reset category if user downgrades and loses access
    const currentCategory = CATEGORIES.find(c => c.name === selectedCategory);
    if (currentCategory && userAccessLevel < TIER_LEVELS[currentCategory.minTier]) {
        setSelectedCategory('Tất cả');
    }
  }, [accountLevel, selectedCategory, userAccessLevel]);

  const availableCategories = useMemo(() => {
    return CATEGORIES.filter(cat => userAccessLevel >= TIER_LEVELS[cat.minTier]);
  }, [userAccessLevel]);

  const filteredArticles = useMemo(() => {
    return newsData
      .filter(article => userAccessLevel >= TIER_LEVELS[article.minTier])
      .filter(article => selectedCategory === 'Tất cả' || article.category === selectedCategory)
      .filter(article => article.title.toLowerCase().includes(searchQuery.toLowerCase()) || article.content.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [userAccessLevel, selectedCategory, searchQuery]);

  const breakingNews = useMemo(() => {
    return filteredArticles.find(a => a.breaking);
  }, [filteredArticles]);

  const handleSelectArticle = (article: NewsArticle) => {
    setSelectedArticle(article);
  }
  
  const handleBackToList = () => {
    setSelectedArticle(null);
  }

  if (selectedArticle) {
    return (
        <div className={`w-full h-full flex flex-col p-4 text-[var(--text-primary)] overflow-y-auto`}>
            <button onClick={handleBackToList} className="flex items-center gap-2 mb-4 text-[var(--accent-color)] hover:underline">
                <ArrowLeft size={18} />
                Quay lại danh sách
            </button>
            <h1 className="text-2xl font-bold mb-2">{selectedArticle.title}</h1>
            <p className="text-sm text-[var(--text-secondary)] mb-4">Trong mục: {selectedArticle.category}</p>
            <div className="prose prose-invert whitespace-pre-wrap text-[var(--text-primary)]">
                {selectedArticle.content}
            </div>
        </div>
    )
  }

  return (
    <div className={`w-full h-full flex text-[var(--text-primary)]`}>
      <aside className="w-48 bg-black/20 p-2 flex-shrink-0 flex flex-col">
        <div className="flex items-center gap-2 p-2 mb-2">
            <Newspaper size={22} style={{ color: 'var(--accent-color)'}}/>
            <h2 className="font-bold text-lg">Stick News</h2>
        </div>
        <nav className="flex flex-col gap-1">
            <button
                onClick={() => setSelectedCategory('Tất cả')}
                className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${selectedCategory === 'Tất cả' ? '' : 'hover:bg-white/10'}`}
                style={selectedCategory === 'Tất cả' ? { backgroundColor: 'var(--accent-color)'} : {}}
            >Tất cả tin tức</button>
          {availableCategories.map(cat => (
            <button
              key={cat.name}
              onClick={() => setSelectedCategory(cat.name)}
              className={`w-full flex items-center gap-2 text-left px-3 py-2 rounded-md text-sm transition-colors ${selectedCategory === cat.name ? '' : 'hover:bg-white/10'}`}
              style={selectedCategory === cat.name ? { backgroundColor: 'var(--accent-color)'} : {}}
            >
              {cat.icon} {cat.name}
            </button>
          ))}
        </nav>
      </aside>

      <main className="flex-grow p-4 overflow-y-auto">
        <div className="relative mb-4">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input 
                type="text"
                placeholder="Tìm kiếm tin tức..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-black/30 rounded-full pl-10 pr-4 py-2 outline-none focus:ring-2"
                style={{ '--tw-ring-color': 'var(--accent-color)' } as React.CSSProperties}
            />
        </div>

        {breakingNews && (
            <div className="bg-red-600/80 p-3 rounded-lg mb-4 border border-red-400 animate-pulse">
                <h3 className="font-bold text-lg">🔥 TIN NÓNG</h3>
                <p>{breakingNews.title}</p>
            </div>
        )}

        <div className="space-y-3">
            {filteredArticles.length > 0 ? filteredArticles.map(article => (
                <div key={article.id} onClick={() => handleSelectArticle(article)} className="bg-white/5 p-3 rounded-lg hover:bg-white/10 cursor-pointer transition-colors">
                    <h3 className="font-semibold text-md">{article.title}</h3>
                    <p className="text-xs text-[var(--text-secondary)]">{article.category}</p>
                </div>
            )) : (
                <div className="text-center text-gray-400 py-10">
                    <p>Không tìm thấy tin tức nào.</p>
                    <p className="text-sm">Hãy thử từ khóa khác hoặc kiểm tra lại sau nhé!</p>
                </div>
            )}
        </div>
      </main>
    </div>
  );
};

export default StickNews;
