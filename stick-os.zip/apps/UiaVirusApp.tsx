import React from 'react';
import { Biohazard } from 'lucide-react';

const UiaVirusApp = () => {
  return (
    <div className="w-full h-full bg-red-900 text-white flex flex-col items-center justify-center p-4 text-center">
      <Biohazard size={48} className="text-red-400 animate-pulse mb-4" />
      <h1 className="text-lg font-bold">UIA VIRUS LOADED</h1>
      <p className="text-sm">Nếu bạn thấy cái này, có gì đó đã sai.</p>
    </div>
  );
};

export default UiaVirusApp;
