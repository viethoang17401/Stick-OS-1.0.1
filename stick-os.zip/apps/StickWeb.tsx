
import React from 'react';
import { ArrowLeft, ArrowRight, RotateCw, Home, Lock } from 'lucide-react';

const StickWeb = () => {
  return (
    <div className="w-full h-full bg-gray-200 text-black flex flex-col">
      <div className="bg-gray-300 p-2 flex items-center gap-2">
        <button className="p-1 text-gray-600 hover:bg-gray-400 rounded"><ArrowLeft size={20} /></button>
        <button className="p-1 text-gray-600 hover:bg-gray-400 rounded"><ArrowRight size={20} /></button>
        <button className="p-1 text-gray-600 hover:bg-gray-400 rounded"><RotateCw size={20} /></button>
        <button className="p-1 text-gray-600 hover:bg-gray-400 rounded"><Home size={20} /></button>
        <div className="flex-grow flex items-center bg-white rounded-full px-3">
            <Lock size={14} className="text-gray-500 mr-2" />
            <input type="text" readOnly value="https://stick-os.hoang.dev" className="w-full bg-transparent py-1 outline-none" />
        </div>
      </div>
      <div className="flex-grow p-8">
        <h1 className="text-4xl font-bold mb-4">Chào mừng đến Stick Web!</h1>
        <p className="text-lg">Đây là trình duyệt mini trong Stick OS Online.</p>
        <p className="mt-2 text-gray-600">Chức năng duyệt web thật chưa được tích hợp, nhưng trông ngầu phải không?</p>
      </div>
    </div>
  );
};

export default StickWeb;
