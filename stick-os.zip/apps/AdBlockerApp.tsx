import React from 'react';
import { useSettings } from '../hooks/useSettings';
import { ShieldCheck, Coins, XCircle } from 'lucide-react';

interface AdBlockerAppProps {
  onClose: () => void;
}

const AdBlockerApp: React.FC<AdBlockerAppProps> = ({ onClose }) => {
    const { hasAdBlocker, purchaseAdBlocker, stickoins } = useSettings();

    const handlePurchase = () => {
        purchaseAdBlocker();
        onClose();
    };

    return (
        <div className="w-full h-full bg-[var(--secondary-bg)] text-[var(--text-primary)] flex flex-col items-center justify-center text-center p-4">
            <ShieldCheck size={48} className="text-green-400 mb-4" />
            
            {hasAdBlocker ? (
                <>
                    <h1 className="text-xl font-bold mb-2">Bạn đã được bảo vệ!</h1>
                    <p className="text-[var(--text-secondary)]">Cảm ơn bạn đã mua trình chặn quảng cáo. Tận hưởng trải nghiệm không bị làm phiền!</p>
                    <button
                        onClick={onClose}
                        className="mt-6 flex items-center justify-center gap-2 w-full bg-gray-600 hover:bg-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition-all"
                    >
                        Tuyệt vời!
                    </button>
                </>
            ) : (
                <>
                    <h1 className="text-xl font-bold mb-2">Loại bỏ Quảng cáo!</h1>
                    <p className="text-[var(--text-secondary)] mb-6">
                        Mệt mỏi với những thông báo "Stick Fun"? Chỉ với 80 Stickoins, bạn có thể loại bỏ chúng vĩnh viễn.
                    </p>
                    <div className="flex flex-col gap-3 w-full">
                        <button
                            onClick={handlePurchase}
                            disabled={stickoins < 80}
                            className="flex items-center justify-center gap-2 w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition-all disabled:bg-gray-500 disabled:cursor-not-allowed"
                        >
                            <Coins size={18} />
                            <span>Mua với giá 80 Coin</span>
                        </button>
                        <button
                            onClick={onClose}
                            className="flex items-center justify-center gap-2 w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition-all"
                        >
                            <XCircle size={18} />
                            <span>Để sau</span>
                        </button>
                    </div>
                </>
            )}
        </div>
    );
};

export default AdBlockerApp;