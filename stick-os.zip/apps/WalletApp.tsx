import React, { useState, useEffect } from 'react';
import { useSettings } from '../hooks/useSettings';
import { Coins, Clock, Gift } from 'lucide-react';
import type { AccountTier } from '../types';

const TIER_REWARDS: Record<AccountTier, { amount: number, cooldown: number }> = {
  'Free': { amount: 100, cooldown: 60 * 1000 },
  'Pro': { amount: 200, cooldown: 30 * 1000 },
  'VIP': { amount: 500, cooldown: 15 * 1000 },
  'ULLTRA': { amount: 1000, cooldown: 10 * 1000 },
  'Super ULLTRA': { amount: 5000, cooldown: 5 * 1000 },
};

const WalletApp = () => {
    const { stickoins, accountLevel, lastClaimTimestamp, claimCoins } = useSettings();
    const [timeLeft, setTimeLeft] = useState(0);

    const tierInfo = TIER_REWARDS[accountLevel];

    useEffect(() => {
        const updateTimer = () => {
            const timePassed = Date.now() - lastClaimTimestamp;
            const remaining = Math.max(0, tierInfo.cooldown - timePassed);
            setTimeLeft(remaining / 1000); // convert to seconds
        };

        updateTimer();
        const interval = setInterval(updateTimer, 500); // Update twice a second for smoothness
        return () => clearInterval(interval);
    }, [lastClaimTimestamp, accountLevel, tierInfo.cooldown]);

    const handleClaim = () => {
        claimCoins();
    };

    return (
        <div className="w-full h-full bg-[var(--secondary-bg)] text-[var(--text-primary)] flex flex-col p-4 font-sans">
            <header className="flex-shrink-0 flex items-center gap-3 pb-4 text-center justify-center">
                <Coins size={28} className="text-yellow-400" />
                <h1 className="text-2xl font-bold">Ví Stickoin</h1>
            </header>

            <main className="flex-grow flex flex-col items-center justify-center text-center">
                <div className="bg-black/30 p-6 rounded-xl w-full max-w-sm mb-6">
                    <p className="text-sm text-[var(--text-secondary)]">Số dư hiện tại</p>
                    <div className="flex items-center justify-center gap-2 mt-2">
                        <h2 className="text-4xl font-bold">{stickoins}</h2>
                        <Coins size={32} className="text-yellow-400" />
                    </div>
                </div>

                <div className="bg-black/20 p-4 rounded-lg w-full max-w-sm">
                     <p className="text-md font-semibold">
                        Phần thưởng hạng <span style={{color: 'var(--accent-color)'}}>{accountLevel}</span>
                     </p>
                     <p className="text-lg my-2">
                        <span className="font-bold text-green-400">+{tierInfo.amount}</span> Stickoins mỗi <span className="font-bold text-cyan-400">{tierInfo.cooldown / 1000}</span> giây
                     </p>

                     <button
                        onClick={handleClaim}
                        disabled={timeLeft > 0}
                        className="w-full flex items-center justify-center gap-2 bg-[var(--accent-color)] hover:brightness-110 text-white font-semibold py-3 px-4 rounded-lg transition-all disabled:bg-gray-600 disabled:cursor-not-allowed mt-4"
                     >
                        {timeLeft > 0 ? (
                            <>
                                <Clock size={18} />
                                <span>Chờ {Math.ceil(timeLeft)} giây</span>
                            </>
                        ) : (
                            <>
                                <Gift size={18} />
                                <span>Nhận thưởng!</span>
                            </>
                        )}
                     </button>
                </div>
            </main>
        </div>
    );
};

export default WalletApp;
