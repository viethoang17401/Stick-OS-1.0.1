import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot } from 'lucide-react';
import { generateText } from '../services/geminiService';
import { useSettings } from '../hooks/useSettings';

interface Message {
  sender: 'user' | 'bot';
  text: string;
}

const GptApp = () => {
  const [messages, setMessages] = useState<Message[]>([
    { sender: 'bot', text: "Xin chào! Tôi là trợ lý AI của Stick OS. Tôi có thể giúp gì cho bạn hôm nay?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { avatarUrl } = useSettings();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSend = async () => {
    if (input.trim() === '' || isLoading) return;

    const userMessage: Message = { sender: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    const botResponseText = await generateText(input);
    const botMessage: Message = { sender: 'bot', text: botResponseText };
    setMessages(prev => [...prev, botMessage]);
    setIsLoading(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <div className="w-full h-full bg-gray-900 text-white flex flex-col">
      <div className="flex-grow p-4 overflow-y-auto space-y-4">
        {messages.map((msg, index) => (
          <div key={index} className={`flex items-start gap-3 ${msg.sender === 'user' ? 'justify-end' : ''}`}>
            {msg.sender === 'bot' && <div className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center" style={{ backgroundColor: 'var(--accent-color)' }}><Bot size={20} /></div>}
            <div className={`max-w-xs md:max-w-md p-3 rounded-lg ${msg.sender === 'user' ? 'rounded-br-none' : 'bg-gray-700 rounded-bl-none'}`} style={msg.sender === 'user' ? { backgroundColor: 'var(--accent-color)'} : {}}>
              <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
            </div>
            {msg.sender === 'user' && (
                avatarUrl ? 
                <img src={avatarUrl} alt="User Avatar" className="w-8 h-8 rounded-full object-cover flex-shrink-0" /> :
                <div className="w-8 h-8 rounded-full bg-blue-600 flex-shrink-0 flex items-center justify-center"><User size={20} /></div>
            )}
          </div>
        ))}
        {isLoading && (
            <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center" style={{ backgroundColor: 'var(--accent-color)' }}><Bot size={20} /></div>
                <div className="max-w-xs p-3 rounded-lg bg-gray-700 rounded-bl-none">
                    <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                        <div className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                        <div className="w-2 h-2 bg-white rounded-full animate-bounce"></div>
                    </div>
                </div>
            </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-2 border-t border-gray-700 flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Nhập tin nhắn..."
          className="w-full bg-gray-800 rounded-lg px-4 py-2 outline-none focus:ring-2"
          style={{ '--tw-ring-color': 'var(--accent-color)' } as React.CSSProperties}
          disabled={isLoading}
        />
        <button onClick={handleSend} disabled={isLoading} className="p-2 rounded-lg hover:brightness-110 disabled:bg-gray-600 disabled:cursor-not-allowed" style={{ backgroundColor: 'var(--accent-color)' }}>
          <Send size={20} />
        </button>
      </div>
    </div>
  );
};

export default GptApp;
