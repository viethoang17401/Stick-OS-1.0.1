import React, { useState } from 'react';
import { ThumbsUp, MessageSquare, Share2, User, Send } from 'lucide-react';
import { useSettings } from '../hooks/useSettings';

interface Comment {
  id: string;
  author: {
    name: string;
    avatarUrl: string | null;
  };
  text: string;
}

interface Post {
  id: string;
  author: {
    name: string;
    avatarUrl: string | null;
  };
  content: string;
  timestamp: string;
  likes: number;
  isLiked: boolean;
  shares: number;
  comments: Comment[];
}

const initialPosts: Post[] = [
  {
    id: 'post-1',
    author: { name: 'Hoàng Người Que', avatarUrl: null },
    content: 'Vừa triển khai Stick OS Online! Sẽ đỉnh lắm đây. Hãy xem hệ điều hành ảo mới của tôi. Nó đầy meme và các tính năng vui nhộn. Mọi người nghĩ sao?',
    timestamp: '2 giờ trước',
    likes: 12,
    isLiked: false,
    shares: 3,
    comments: [
      { id: 'comment-1', author: { name: 'Botu', avatarUrl: null }, text: 'Tuyệt vời, nhưng nút tự hủy ở đâu?' }
    ]
  },
  {
    id: 'post-2',
    author: { name: 'AI-chan', avatarUrl: null },
    content: 'Phân tích dữ liệu cho thấy 99.9% người dùng sẽ bấm vào ứng dụng Troll. Con người thật dễ đoán. 🤖',
    timestamp: '5 giờ trước',
    likes: 25,
    isLiked: true,
    shares: 7,
    comments: []
  }
];


const StickFace = () => {
  const { username, avatarUrl } = useSettings();
  const [posts, setPosts] = useState<Post[]>(initialPosts);
  const [newPostContent, setNewPostContent] = useState('');
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});

  const handlePostSubmit = () => {
    if (newPostContent.trim() === '') return;

    const newPost: Post = {
      id: `post-${Date.now()}`,
      author: { name: username || 'Người dùng', avatarUrl },
      content: newPostContent,
      timestamp: 'Vừa xong',
      likes: 0,
      isLiked: false,
      shares: 0,
      comments: []
    };

    setPosts([newPost, ...posts]);
    setNewPostContent('');
  };
  
  const handleLike = (postId: string) => {
    setPosts(posts.map(post => {
        if (post.id === postId) {
            return {
                ...post,
                isLiked: !post.isLiked,
                likes: post.isLiked ? post.likes - 1 : post.likes + 1
            };
        }
        return post;
    }));
  };
  
  const handleShare = (postId: string) => {
      setPosts(posts.map(post => 
        post.id === postId ? { ...post, shares: post.shares + 1 } : post
      ));
      // In a real app, this would open a share dialog
      alert('Đã chia sẻ bài viết! (Tính năng mô phỏng)');
  };

  const handleCommentSubmit = (postId: string) => {
    const commentText = commentInputs[postId];
    if (!commentText || commentText.trim() === '') return;
    
    const newComment: Comment = {
        id: `comment-${Date.now()}`,
        author: { name: username || 'Người dùng', avatarUrl },
        text: commentText
    };

    setPosts(posts.map(post => {
        if (post.id === postId) {
            return { ...post, comments: [...post.comments, newComment] };
        }
        return post;
    }));
    
    setCommentInputs(prev => ({ ...prev, [postId]: '' }));
  };


  return (
    <div className="w-full h-full bg-gray-800 text-white overflow-y-auto p-4">
      <div className="max-w-2xl mx-auto">
        {/* Post Input */}
        <div className="bg-gray-700 p-3 rounded-lg mb-6">
            <div className="flex items-center gap-3 mb-2">
                {avatarUrl ? 
                    <img src={avatarUrl} alt="User Avatar" className="w-10 h-10 rounded-full object-cover"/> :
                    <div className="w-10 h-10 rounded-full bg-gray-600 flex items-center justify-center">
                        <User size={24} />
                    </div>
                }
                <textarea 
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    placeholder={`Bạn đang nghĩ gì thế, ${username}?`} 
                    className="w-full bg-gray-600 rounded-lg px-4 py-2 outline-none resize-none"
                    rows={2}
                />
            </div>
            <button 
                onClick={handlePostSubmit}
                style={{ backgroundColor: 'var(--accent-color)' }}
                className="w-full hover:brightness-110 text-white font-semibold py-2 px-4 rounded-lg transition-all"
            >
                Đăng bài
            </button>
        </div>
        
        {/* Feed Posts */}
        <div className="space-y-6">
            {posts.map((post, index) => (
              <div 
                key={post.id} 
                className={`bg-gray-700 rounded-lg ${index === 0 && post.timestamp === 'Vừa xong' ? 'animate-post-appear' : ''}`}
              >
                <div className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    {post.author.avatarUrl ?
                        <img src={post.author.avatarUrl} alt="User Avatar" className="w-10 h-10 rounded-full object-cover"/> :
                        <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center font-bold">{post.author.name.charAt(0)}</div>
                    }
                    <div>
                      <p className="font-semibold">{post.author.name}</p>
                      <p className="text-xs text-gray-400">{post.timestamp}</p>
                    </div>
                  </div>
                  <p className="mb-3 whitespace-pre-wrap">{post.content}</p>
                </div>
                {/* Stats */}
                <div className="px-4 pb-2 flex justify-between text-xs text-gray-400">
                    <span>{post.likes} lượt thích</span>
                    <span>{post.comments.length} bình luận • {post.shares} lượt chia sẻ</span>
                </div>
                {/* Actions */}
                <div className="border-t border-b border-gray-600 flex justify-around p-1">
                  <button onClick={() => handleLike(post.id)} className={`flex items-center gap-2 p-2 rounded-md w-full justify-center transition-colors ${post.isLiked ? 'hover:bg-white/10' : 'text-gray-300 hover:bg-gray-600'}`} style={post.isLiked ? { color: 'var(--accent-color)' } : {}}><ThumbsUp size={20} /> Thích</button>
                  <button className="flex items-center gap-2 text-gray-300 hover:bg-gray-600 p-2 rounded-md w-full justify-center"><MessageSquare size={20} /> Bình luận</button>
                  <button onClick={() => handleShare(post.id)} className="flex items-center gap-2 text-gray-300 hover:bg-gray-600 p-2 rounded-md w-full justify-center"><Share2 size={20} /> Chia sẻ</button>
                </div>
                {/* Comments Section */}
                <div className="p-4 space-y-3">
                    {post.comments.map(comment => (
                        <div key={comment.id} className="flex items-start gap-2">
                             {comment.author.avatarUrl ?
                                <img src={comment.author.avatarUrl} alt="User Avatar" className="w-8 h-8 rounded-full object-cover"/> :
                                <div className="w-8 h-8 bg-gray-500 rounded-full flex-shrink-0 flex items-center justify-center font-bold text-sm">{comment.author.name.charAt(0)}</div>
                            }
                            <div className="bg-gray-600 rounded-lg px-3 py-1">
                                <p className="font-semibold text-sm">{comment.author.name}</p>
                                <p className="text-sm">{comment.text}</p>
                            </div>
                        </div>
                    ))}
                    {/* Comment Input */}
                    <div className="flex items-center gap-2 pt-2">
                        {avatarUrl ? 
                            <img src={avatarUrl} alt="User Avatar" className="w-8 h-8 rounded-full object-cover"/> :
                            <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center flex-shrink-0">
                                <User size={18} />
                            </div>
                        }
                        <div className="w-full flex items-center bg-gray-600 rounded-full">
                            <input 
                                type="text" 
                                placeholder="Viết bình luận..." 
                                value={commentInputs[post.id] || ''}
                                onChange={(e) => setCommentInputs(prev => ({...prev, [post.id]: e.target.value }))}
                                onKeyPress={(e) => e.key === 'Enter' && handleCommentSubmit(post.id)}
                                className="w-full bg-transparent px-4 py-1 outline-none" 
                            />
                            <button onClick={() => handleCommentSubmit(post.id)} className="p-2 text-gray-300 hover:text-white">
                                <Send size={16} />
                            </button>
                        </div>
                    </div>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default StickFace;
