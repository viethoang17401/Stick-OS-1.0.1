import React, { useState } from 'react';
import { HardDrive, Folder, FileText, ChevronRight, ArrowUp } from 'lucide-react';
import { VIRTUAL_FILE_SYSTEM, getItemsFromPath, FSItem } from '../data/filesystem';

const defaultFileIcon = <FileText size={32} />;
const folderIcon = <Folder size={32} />;

const ThisPCApp = () => {
    const [path, setPath] = useState<string[]>(['C:']);
    const [selectedItem, setSelectedItem] = useState<string | null>(null);

    const currentItems = getItemsFromPath(path) || [];

    const handleItemDoubleClick = (item: FSItem) => {
        if (item.type === 'folder') {
            setPath(prevPath => [...prevPath, item.name]);
            setSelectedItem(null);
        } else {
            // Maybe show a file info dialog in the future
            alert(`Tệp: ${item.name}\nKích thước: ${item.size || 'Không rõ'}`);
        }
    };
    
    const handleItemClick = (item: FSItem) => {
        setSelectedItem(item.name);
    }

    const navigateToPath = (index: number) => {
        setPath(path.slice(0, index + 1));
        setSelectedItem(null);
    };
    
    const navigateUp = () => {
        if (path.length > 1) {
            setPath(path.slice(0, -1));
            setSelectedItem(null);
        }
    }

    const navigateToDrive = (drive: string) => {
        setPath([drive]);
        setSelectedItem(null);
    };

    return (
        <div className="w-full h-full bg-[var(--secondary-bg)] text-[var(--text-primary)] flex flex-col font-sans">
            {/* Toolbar */}
            <div className="flex-shrink-0 flex items-center gap-2 p-1 bg-black/20 border-b" style={{ borderColor: 'var(--border-color)'}}>
                <button onClick={navigateUp} disabled={path.length <= 1} className="p-1 rounded hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed">
                    <ArrowUp size={18} />
                </button>
                <div className="flex-grow flex items-center bg-black/20 rounded px-2 py-1 text-sm">
                    {path.map((segment, index) => (
                        <React.Fragment key={index}>
                            <button onClick={() => navigateToPath(index)} className="hover:underline">
                                {segment}
                            </button>
                            {index < path.length - 1 && <ChevronRight size={16} className="mx-1" />}
                        </React.Fragment>
                    ))}
                </div>
            </div>

            <div className="flex-grow flex overflow-hidden">
                {/* Sidebar */}
                <aside className="w-40 flex-shrink-0 bg-black/10 p-2 overflow-y-auto">
                    <h3 className="font-bold text-sm text-[var(--text-secondary)] mb-2 px-1">Ổ đĩa</h3>
                    <ul className="space-y-1">
                        {Object.keys(VIRTUAL_FILE_SYSTEM).map(drive => (
                            <li key={drive}>
                                <button 
                                    onClick={() => navigateToDrive(drive)} 
                                    className={`w-full flex items-center gap-2 p-1 rounded text-left text-sm ${path[0] === drive && path.length === 1 ? '' : 'hover:bg-white/10'}`}
                                    style={path[0] === drive && path.length === 1 ? { backgroundColor: 'var(--accent-color)'} : {}}
                                >
                                    <HardDrive size={16} />
                                    <span>{drive}</span>
                                </button>
                            </li>
                        ))}
                    </ul>
                </aside>
                
                {/* Main Content */}
                <main className="flex-grow p-2 overflow-y-auto" onClick={() => setSelectedItem(null)}>
                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-4">
                        {currentItems.map((item) => (
                            <div
                                key={item.name}
                                onClick={(e) => { e.stopPropagation(); handleItemClick(item); }}
                                onDoubleClick={() => handleItemDoubleClick(item)}
                                className={`flex flex-col items-center text-center p-2 rounded-lg cursor-pointer ${selectedItem === item.name ? '' : 'hover:bg-[var(--accent-color-light)]'}`}
                                style={selectedItem === item.name ? { backgroundColor: 'var(--accent-color)'} : {}}
                            >
                                <div className="mb-1" style={{ color: 'var(--accent-color)' }}>
                                    {item.type === 'folder' ? (item.icon || folderIcon) : (item.icon || defaultFileIcon)}
                                </div>
                                <span className="text-xs break-all w-full">{item.name}</span>
                            </div>
                        ))}
                        {currentItems.length === 0 && (
                            <div className="col-span-full text-center text-gray-500 mt-8">
                                Thư mục này trống.
                            </div>
                        )}
                    </div>
                </main>
            </div>
        </div>
    );
};

export default ThisPCApp;
