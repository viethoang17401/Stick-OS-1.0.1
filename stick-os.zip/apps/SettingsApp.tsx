import React, { useState, useRef } from 'react';
import { User, Image as ImageIcon, CheckCircle, Edit3, Palette, Lock, Play } from 'lucide-react';
import { useSettings } from '../hooks/useSettings';
import { PREDEFINED_WALLPAPERS, THEMES } from '../constants';
import type { AccountTier, ThemeColors } from '../types';

const TIER_FEATURES: Record<AccountTier, string[]> = {
    'Free': ['Giao diện Cơ bản', '3 Hình nền'],
    'Pro': ['Mọi thứ trong Miễn phí', '+ 3 Giao diện độc quyền', '+2 Hình nền Độc quyền'],
    'VIP': ['Mọi thứ trong Pro', '+ 2 Giao diện độc quyền', '+ 3 Hình nền Độc quyền (có hình động)'],
    'ULLTRA': ['Mọi thứ trong VIP', '+ 2 Giao diện độc quyền', '+ 2 Hình nền Độc quyền'],
    'Super ULLTRA': ['Mọi thứ trong ULLTRA', '+ 2 Hình nền Hacker Bí mật', '+ Quyền được khoe 😎'],
};

const COLOR_LABELS: Record<keyof ThemeColors, string> = {
    '--primary-bg': 'Nền Chính',
    '--secondary-bg': 'Nền Phụ',
    '--window-bg': 'Nền Cửa sổ',
    '--header-bg': 'Nền Header',
    '--accent-color': 'Màu Nhấn',
    '--accent-color-light': 'Màu Nhấn (Sáng)',
    '--text-primary': 'Màu Chữ Chính',
    '--text-secondary': 'Màu Chữ Phụ',
    '--border-color': 'Màu Viền',
    '--focus-ring-color': 'Màu Vòng Focus',
};

const SettingsApp = () => {
  const [activeTab, setActiveTab] = useState<'account' | 'wallpaper' | 'theme'>('account');
  const { 
      accountLevel, setAccountLevel, 
      wallpaperUrl, setWallpaperUrl, uploadWallpaper,
      username, setUsername, avatarUrl, uploadAvatar,
      themeId, setThemeId,
      customThemeColors, updateCustomTheme, resetCustomTheme,
      getCurrentTheme
  } = useSettings();
  const wallpaperInputRef = useRef<HTMLInputElement>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  const handleWallpaperFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      uploadWallpaper(file);
    }
  };
  
  const handleAvatarFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      uploadAvatar(file);
    }
  };

  const SidebarItem: React.FC<{ tabId: 'account' | 'wallpaper' | 'theme', icon: React.ReactNode, label: string }> = ({ tabId, icon, label }) => (
    <button
        onClick={() => setActiveTab(tabId)}
        onMouseDown={(e) => e.stopPropagation()} // Prevent parent window's onMouseDown from interfering
        className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-left transition-colors ${activeTab === tabId ? 'bg-[var(--accent-color)] text-white' : 'hover:bg-gray-700'}`}
    >
        {icon}
        <span>{label}</span>
    </button>
  );

  const getTierAccessLevel = (tier: AccountTier): number => {
    const levels = {'Free': 0, 'Pro': 1, 'VIP': 2, 'ULLTRA': 3, 'Super ULLTRA': 4};
    return levels[tier];
  }

  const currentAccessLevel = getTierAccessLevel(accountLevel);
  const canCustomize = currentAccessLevel >= getTierAccessLevel('VIP');

  const handleColorChange = (key: keyof ThemeColors, value: string) => {
    const currentTheme = getCurrentTheme();
    // Use the currently rendered theme's colors as a base if no custom theme exists yet.
    const baseColors = customThemeColors || currentTheme.colors;
    const newColors = { ...baseColors, [key]: value };
    updateCustomTheme(newColors);
    if (themeId !== 'custom') {
        setThemeId('custom');
    }
  };

  const handleResetCustomTheme = () => {
    resetCustomTheme();
  };
  
  const themeToDisplayInPicker = customThemeColors || getCurrentTheme().colors;


  return (
    <div className="w-full h-full bg-[var(--secondary-bg)] text-[var(--text-primary)] flex relative">
      {/* Sidebar */}
      <aside className="w-48 bg-black/20 p-3 flex-shrink-0 flex flex-col gap-2">
        <SidebarItem tabId="account" icon={<User size={20} />} label="Tài khoản" />
        <SidebarItem tabId="wallpaper" icon={<ImageIcon size={20} />} label="Hình nền" />
        <SidebarItem tabId="theme" icon={<Palette size={20} />} label="Giao diện" />
      </aside>

      {/* Main Content */}
      <main className="flex-grow p-6 overflow-y-auto">
        {activeTab === 'account' && (
          <div>
            <h1 className="text-2xl font-bold mb-4">Tài khoản</h1>
            <p className="text-[var(--text-secondary)] mb-6">Cá nhân hóa thông tin và cấp bậc tài khoản của bạn.</p>
            
            <div className="bg-black/20 p-4 rounded-lg mb-8">
                <h2 className="text-lg font-semibold mb-4">Thông tin Cá nhân</h2>
                <div className="flex items-center gap-4">
                    <div className="relative group cursor-pointer" onClick={() => avatarInputRef.current?.click()}>
                        {avatarUrl ? 
                            <img src={avatarUrl} alt="Avatar" className="w-16 h-16 rounded-full object-cover"/> :
                            <div className="w-16 h-16 rounded-full bg-gray-600 flex items-center justify-center">
                                <User size={32} />
                            </div>
                        }
                        <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <Edit3 size={24} />
                        </div>
                    </div>
                    <input type="file" ref={avatarInputRef} onChange={handleAvatarFileChange} accept="image/*" className="hidden"/>
                    <div className="flex-grow">
                        <label htmlFor="username" className="block text-sm font-medium text-gray-300 mb-1">Tên hiển thị</label>
                        <input
                            id="username"
                            type="text"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            className="w-full bg-gray-800 border border-gray-600 rounded-md px-3 py-2 outline-none focus:ring-2 focus:ring-[var(--accent-color)]"
                        />
                    </div>
                </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-lg font-semibold">Hạng Tài khoản</h2>
              {(Object.keys(TIER_FEATURES) as AccountTier[]).map(tier => (
                <div 
                  key={tier}
                  onClick={() => setAccountLevel(tier)}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${accountLevel === tier ? 'border-[var(--accent-color)] bg-[var(--accent-color-light)]' : 'border-gray-700 hover:border-[var(--accent-color)]'}`}
                >
                  <h2 className="text-lg font-semibold">{tier}</h2>
                  <ul className="text-sm text-gray-300 mt-2 list-disc list-inside space-y-1">
                    {TIER_FEATURES[tier].map(feature => <li key={feature}>{feature}</li>)}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'wallpaper' && (
           <div>
             <h1 className="text-2xl font-bold mb-4">Cá nhân hóa Hình nền</h1>
             <p className="text-[var(--text-secondary)] mb-6">Chọn một hình nền hoặc tải lên hình của bạn.</p>
             <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {PREDEFINED_WALLPAPERS.map(wp => {
                    const requiredLevel = getTierAccessLevel(wp.tier as AccountTier);
                    const hasAccess = currentAccessLevel >= requiredLevel;
                    return (
                        <div key={wp.id} className={`relative group ${hasAccess ? 'cursor-pointer' : 'cursor-not-allowed'}`} onClick={() => hasAccess && setWallpaperUrl(wp.url)}>
                            <img src={wp.thumbnailUrl || wp.url} alt={wp.name} className={`w-full h-24 object-cover rounded-md ${!hasAccess && 'grayscale opacity-50'}`} />
                            {wp.type === 'video' && (
                                <div className="absolute inset-0 bg-black/20 flex items-center justify-center pointer-events-none">
                                    <Play size={32} className={`text-white drop-shadow-lg ${!hasAccess ? 'opacity-70' : ''}`} />
                                </div>
                            )}
                            <div className={`absolute inset-0 bg-black/50 flex items-center justify-center text-center p-1 opacity-0 ${hasAccess && 'group-hover:opacity-100'} transition-opacity`}>
                                <span className="text-white text-sm">{wp.name}<br/>
                                {!hasAccess && <span className='text-xs text-yellow-400'>(Hạng {wp.tier})</span>}
                                </span>
                            </div>
                            {wallpaperUrl === wp.url && (
                                <div className="absolute top-1 right-1 bg-green-500 rounded-full p-1">
                                    <CheckCircle size={16} className="text-white"/>
                                </div>
                            )}
                        </div>
                    )
                })}
                <div 
                    onClick={() => wallpaperInputRef.current?.click()}
                    className="w-full h-24 bg-gray-700 rounded-md flex flex-col items-center justify-center cursor-pointer hover:bg-gray-600"
                >
                    <ImageIcon size={24} />
                    <span className="text-sm mt-1">Tải ảnh lên</span>
                    <input
                      type="file"
                      ref={wallpaperInputRef}
                      onChange={handleWallpaperFileChange}
                      accept="image/*"
                      className="hidden"
                    />
                </div>
             </div>
           </div>
        )}

        {activeTab === 'theme' && (
            <div>
                 <h1 className="text-2xl font-bold mb-4">Tùy chỉnh Giao diện</h1>
                 <p className="text-[var(--text-secondary)] mb-6">Thay đổi toàn bộ màu sắc của Stick OS.</p>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {THEMES.map(theme => {
                         const requiredLevel = getTierAccessLevel(theme.tier);
                         const hasAccess = currentAccessLevel >= requiredLevel;
                         return (
                            <div 
                                key={theme.id} 
                                className={`p-4 rounded-lg border-2 transition-all ${themeId === theme.id ? 'border-[var(--accent-color)] bg-[var(--accent-color-light)]' : 'border-gray-700'} ${hasAccess ? 'cursor-pointer hover:border-[var(--accent-color)]' : 'cursor-not-allowed opacity-60'}`}
                                onClick={() => hasAccess && setThemeId(theme.id)}
                            >
                                <div className="flex justify-between items-center mb-3">
                                    <h3 className="font-semibold">{theme.name}</h3>
                                    {!hasAccess && <span className="text-xs bg-yellow-500/20 text-yellow-300 px-2 py-1 rounded-full flex items-center gap-1"><Lock size={12}/> Hạng {theme.tier}</span>}
                                </div>
                                <div className="flex gap-2 h-10">
                                    <div className="w-1/4 rounded" style={{ backgroundColor: theme.colors['--primary-bg'] }}></div>
                                    <div className="w-1/4 rounded" style={{ backgroundColor: theme.colors['--secondary-bg'] }}></div>
                                    <div className="w-1/4 rounded" style={{ backgroundColor: theme.colors['--accent-color'] }}></div>
                                    <div className="w-1/4 rounded flex items-center justify-center" style={{ backgroundColor: theme.colors['--window-bg'] }}>
                                        <span style={{ color: theme.colors['--text-primary'] }}>Aa</span>
                                    </div>
                                </div>
                            </div>
                         )
                    })}
                 </div>

                 {canCustomize ? (
                    <div className="mt-8 pt-6 border-t border-[var(--border-color)]">
                        <div className="flex justify-between items-center mb-4">
                            <h2 className="text-lg font-semibold">Trình tùy chỉnh Giao diện</h2>
                            <button
                                onClick={handleResetCustomTheme}
                                className="text-sm bg-red-500/80 text-white px-3 py-1 rounded-md hover:bg-red-500 disabled:opacity-50 disabled:cursor-not-allowed"
                                disabled={!customThemeColors}
                            >
                                Đặt lại Tùy chỉnh
                            </button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4 p-4 bg-black/20 rounded-lg">
                            {(Object.keys(COLOR_LABELS) as Array<keyof ThemeColors>).map((key) => (
                                <div key={key} className="flex items-center justify-between">
                                    <label htmlFor={`color-${key}`} className="text-sm text-gray-300">{COLOR_LABELS[key]}</label>
                                    <input
                                        id={`color-${key}`}
                                        type="color"
                                        value={themeToDisplayInPicker[key]}
                                        onChange={(e) => handleColorChange(key, e.target.value)}
                                        className="w-10 h-8 p-0 border-none bg-transparent rounded cursor-pointer"
                                    />
                                </div>
                            ))}
                        </div>
                        <p className="text-xs text-[var(--text-secondary)] mt-2">Mọi thay đổi sẽ được áp dụng ngay lập tức. Giao diện tùy chỉnh của bạn sẽ được lưu tự động.</p>
                    </div>
                 ) : (
                    <div className="mt-8 pt-6 border-t border-gray-700 text-center bg-black/20 p-6 rounded-lg">
                         <h2 className="text-lg font-semibold mb-2 text-yellow-300">Nâng cấp để Mở khóa Tùy chỉnh!</h2>
                         <p className="text-gray-300">Trở thành thành viên <span className="font-bold text-purple-400">VIP</span> để tạo giao diện độc đáo của riêng bạn.</p>
                    </div>
                 )}
            </div>
        )}

      </main>
      <div className="absolute bottom-2 right-4 text-xs text-gray-600 opacity-50 select-none">
        @2025byviethoang
      </div>
    </div>
  );
};

export default SettingsApp;