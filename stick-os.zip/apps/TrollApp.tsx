import React, { useState, useRef } from 'react';

interface TrollAppProps {
  onClose?: () => void;
}

const TrollApp: React.FC<TrollAppProps> = ({ onClose }) => {
  const [isExploding, setIsExploding] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  
  const handleExplosion = () => {
    // Prevent multiple clicks from running the logic again
    if (isExploding) return;

    setIsExploding(true);

    const audio = audioRef.current;
    if (audio && onClose) {
      // Sound source: https://pixabay.com/sound-effects/explosion-6055/
      audio.src = 'https://cdn.pixabay.com/download/audio/2022/03/10/audio_c382372481.mp3';
      
      // Create a one-time listener that closes the window when the audio finishes playing.
      const onAudioEnd = () => {
        onClose();
        audio.removeEventListener('ended', onAudioEnd); // Clean up the listener
      };
      audio.addEventListener('ended', onAudioEnd);
      
      const playPromise = audio.play();

      if (playPromise !== undefined) {
        playPromise.catch(error => {
          console.error("Audio play failed:", error);
          // If audio fails to play, remove the listener and fall back to a timeout.
          audio.removeEventListener('ended', onAudioEnd);
          setTimeout(onClose, 1200); 
        });
      }
    } else if (onClose) {
        // Fallback if the audio element isn't ready for some reason
        setTimeout(onClose, 1200);
    }
  };

  return (
    <div className={`w-full h-full flex flex-col items-center justify-center p-4 text-center transition-colors duration-200 ${isExploding ? 'bg-transparent' : 'bg-yellow-300'}`}>
      {isExploding ? (
        <img 
          src="https://gifdb.com/images/high/pixel-art-explosion-212-x-200-gif-359u1gr04s8u28hf.gif" 
          alt="Explosion"
          className="object-contain"
        />
      ) : (
        <>
          <h1 className="text-2xl font-bold mb-4 text-black">Ứng dụng Troll</h1>
          <p className="mb-4 text-black">Bấm nút để có bất ngờ!</p>
          <button 
            onClick={handleExplosion}
            className="bg-red-500 text-white font-bold py-2 px-4 rounded-lg shadow-lg transform hover:scale-110 transition-transform"
          >
            Đừng Bấm
          </button>
        </>
      )}
      <audio ref={audioRef} style={{ display: 'none' }} />
    </div>
  );
};

export default TrollApp;