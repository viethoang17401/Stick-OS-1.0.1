import React from 'react';
import { useSettings } from '../hooks/useSettings';
import { STORE_ITEMS } from '../constants';
import { ShoppingCart, Check, PlusCircle, Coins, Lock } from 'lucide-react';
import type { AccountTier } from '../types';

const TIER_LEVELS: Record<AccountTier, number> = {
  'Free': 0, 'Pro': 1, 'VIP': 2, 'ULLTRA': 3, 'Super ULLTRA': 4
};

const StoreApp = () => {
    const { 
        stickoins, 
        purchasedItemIds, 
        buyItem, 
        addWidget, 
        accountLevel 
    } = useSettings();
    
    const userAccessLevel = TIER_LEVELS[accountLevel];

    return (
        <div className="w-full h-full bg-[var(--secondary-bg)] text-[var(--text-primary)] flex flex-col p-4">
            <header className="flex-shrink-0 flex items-center justify-between pb-4 border-b" style={{ borderColor: 'var(--border-color)'}}>
                <div className="flex items-center gap-3">
                    <ShoppingCart size={28} className="text-[var(--accent-color)]" />
                    <h1 className="text-2xl font-bold">Cửa hàng Stick OS</h1>
                </div>
                <div className="flex items-center gap-2 bg-black/30 px-3 py-1.5 rounded-full">
                    <Coins size={20} className="text-yellow-400" />
                    <span className="font-semibold text-lg">{stickoins}</span>
                </div>
            </header>

            <main className="flex-grow pt-4 overflow-y-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {STORE_ITEMS.map(item => {
                        const isPurchased = purchasedItemIds.includes(item.id);
                        const canAfford = stickoins >= item.price;
                        const hasAccess = userAccessLevel >= TIER_LEVELS[item.tier];

                        return (
                            <div key={item.id} className={`bg-black/20 p-4 rounded-lg flex flex-col ${!hasAccess && 'opacity-60'}`}>
                                <div className="bg-black/20 h-32 rounded-md flex items-center justify-center mb-3 text-5xl">
                                    <span>🚶</span>
                                </div>
                                <div className="flex justify-between items-start">
                                    <h2 className="text-lg font-semibold">{item.name}</h2>
                                    {!hasAccess && (
                                         <span className="text-xs bg-yellow-500/20 text-yellow-300 px-2 py-1 rounded-full flex items-center gap-1"><Lock size={12}/> Hạng {item.tier}</span>
                                    )}
                                </div>
                                <p className="text-sm text-[var(--text-secondary)] flex-grow mt-1">{item.description}</p>
                                <div className="mt-4">
                                    {isPurchased ? (
                                        <button 
                                            onClick={() => addWidget(item.id)}
                                            className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition-all"
                                        >
                                            <PlusCircle size={18}/>
                                            Sử dụng
                                        </button>
                                    ) : (
                                        <button
                                            onClick={() => buyItem(item.id)}
                                            disabled={!canAfford || !hasAccess}
                                            className="w-full flex items-center justify-center gap-2 bg-[var(--accent-color)] hover:brightness-110 text-white font-semibold py-2 px-4 rounded-lg transition-all disabled:bg-gray-600 disabled:cursor-not-allowed"
                                        >
                                            <Coins size={18}/>
                                            Mua với giá {item.price}
                                        </button>
                                    )}
                                </div>
                            </div>
                        )
                    })}
                </div>
            </main>
        </div>
    );
};

export default StoreApp;
