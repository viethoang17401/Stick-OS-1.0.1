
import React, { useState } from 'react';

const RepApp = () => {
    const [code, setCode] = useState('// Viết mã JavaScript của bạn ở đây\nconsole.log("Xin chào từ Stick OS!");');
    const [output, setOutput] = useState('');

    const runCode = () => {
        try {
            // This is a very basic and unsafe way to run code.
            // In a real app, this should be sandboxed!
            let capturedOutput = '';
            const originalLog = console.log;
            console.log = (...args) => {
                capturedOutput += args.map(String).join(' ') + '\\n';
                originalLog.apply(console, args);
            };
            eval(code);
            console.log = originalLog;
            setOutput(capturedOutput || 'Mã đã chạy thành công không có kết quả.');
        } catch (error) {
            if (error instanceof Error) {
                setOutput(`Lỗi: ${error.message}`);
            } else {
                setOutput('Đã xảy ra lỗi không xác định.');
            }
        }
    }

  return (
    <div className="w-full h-full bg-gray-900 text-white flex flex-col font-mono">
        <div className="flex-grow flex flex-col md:flex-row">
            <div className="w-full md:w-1/2 h-1/2 md:h-full p-2 flex flex-col">
                <textarea 
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full h-full bg-gray-800 text-green-400 p-3 rounded-md outline-none resize-none"
                    spellCheck="false"
                />
            </div>
            <div className="w-full md:w-1/2 h-1/2 md:h-full p-2 flex flex-col">
                <div className="w-full h-full bg-black text-white p-3 rounded-md overflow-auto">
                    <pre>{output}</pre>
                </div>
            </div>
        </div>
      <div className="p-2 border-t border-gray-700">
        <button onClick={runCode} className="bg-green-600 px-4 py-2 rounded hover:bg-green-700">Chạy Mã</button>
      </div>
    </div>
  );
};

export default RepApp;
