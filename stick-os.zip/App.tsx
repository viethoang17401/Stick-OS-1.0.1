
import React, { useEffect, useState } from 'react';
import Desktop from './components/Desktop';
import Taskbar from './components/Taskbar';
import Window from './components/Window';
import Dock from './components/Dock';
import BSOD from './components/BSOD';
import ReinstallingScreen from './components/ReinstallingScreen';
import LockScreen from './components/LockScreen';
import AnnoyingAd from './components/AnnoyingAd';
import { APPS } from './constants';
import { WindowsProvider, useWindows } from './hooks/useWindows';
import { SettingsProvider, useSettings } from './hooks/useSettings';
import { SystemProvider, useSystem } from './hooks/useSystem';

const ThemeStyles = () => {
  const { getCurrentTheme } = useSettings();
  const theme = getCurrentTheme();

  const cssVariables = Object.entries(theme.colors)
    .map(([key, value]) => `${key}: ${value};`)
    .join('\n');

  return <style>{`:root { ${cssVariables} }`}</style>;
};

const AD_MESSAGES = [
    "Stick fun. fun anh fun",
    "PC của bạn sắp hết RAM ảo... bấm vào đây để tải thêm!",
    "Mua VIP đi bạn ơi!",
    "Bạn có biết 99% người chơi không thể qua màn 2 Stick Runner?",
    "Click vào đây để nhận một con mèo miễn phí! (Đùa thôi)",
    "Thông báo: Bạn có một thông báo mới.",
];

interface AppContentProps {
  onLogout: () => void;
}

const AppContent: React.FC<AppContentProps> = ({ onLogout }) => {
  const { windows, windowsHidden } = useWindows();
  const { systemState, startReinstall } = useSystem();
  const { hasAdBlocker } = useSettings();
  const [showWarning, setShowWarning] = useState(false);
  const [ad, setAd] = useState<{ id: number, message: string } | null>(null);

  useEffect(() => {
    const openWindowsCount = windows.filter(w => !w.isMinimized).length;
    if (openWindowsCount > 5) {
      setShowWarning(true);
    }
  }, [windows]);

  // Ad display logic
  useEffect(() => {
    if (hasAdBlocker) {
        setAd(null); // Clear any existing ad if user purchases ad blocker
        return;
    }

    let adTimer: number;

    const scheduleNextAd = () => {
        clearTimeout(adTimer);
        const randomDelay = 15000 + Math.random() * 15000; // 15-30 seconds
        adTimer = window.setTimeout(showAd, randomDelay);
    };

    const showAd = () => {
        const randomMessage = AD_MESSAGES[Math.floor(Math.random() * AD_MESSAGES.length)];
        setAd({ id: Date.now(), message: randomMessage });
        
        // Ad disappears after some time
        setTimeout(() => {
            setAd(null);
            scheduleNextAd(); // Schedule the next one after this one is gone
        }, 5000); // Ad stays for 5 seconds
    };

    scheduleNextAd(); // Start the cycle

    return () => clearTimeout(adTimer); // Cleanup on component unmount
  }, [hasAdBlocker]);
  
  const handleCloseWarning = () => {
    setShowWarning(false);
  }

  if (systemState === 'bsod') {
    return <BSOD onReset={startReinstall} />;
  }
  if (systemState === 'reinstalling') {
    return <ReinstallingScreen onComplete={() => window.location.reload()} />;
  }
  
  const appClassName = systemState === 'glitching' ? 'glitch-effect' : '';
  const isAnyWindowMaximized = windows.some(w => w.isMaximized);

  return (
    <div className={`h-screen w-screen bg-black overflow-hidden relative ${appClassName}`}>
      <Desktop />
      {!windowsHidden && windows.map((win) => {
        const app = APPS.find((appDef) => appDef.id === win.appId);
        if (!app) return null;
        return <Window key={win.id} windowState={win} app={app} />;
      })}
      <Dock isHidden={isAnyWindowMaximized} />
      <Taskbar onLogout={onLogout} />
      {showWarning && (
        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm z-[99998] flex items-center justify-center">
          <div className="bg-yellow-400 border-4 border-black text-black p-8 rounded-lg shadow-2xl text-center">
            <h2 className="text-3xl font-bold mb-4">⚠️ CẢNH BÁO ⚠️</h2>
            <p className="text-lg">Máy bạn sắp nổ vì mở quá 5 cửa sổ!</p>
            <button 
              onClick={handleCloseWarning} 
              className="mt-6 bg-red-600 text-white font-bold py-2 px-6 rounded hover:bg-red-700"
            >
              OK, liều ăn nhiều!
            </button>
          </div>
        </div>
      )}
      {ad && <AnnoyingAd key={ad.id} message={ad.message} onClose={() => setAd(null)} />}
    </div>
  );
};

const Main: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  if (!isAuthenticated) {
    return <LockScreen onLogin={() => setIsAuthenticated(true)} />;
  }
  
  return <AppContent onLogout={() => setIsAuthenticated(false)} />;
};

const App: React.FC = () => {
  return (
    <SettingsProvider>
      <ThemeStyles />
      <WindowsProvider>
        <SystemProvider>
          <Main />
        </SystemProvider>
      </WindowsProvider>
    </SettingsProvider>
  );
};

export default App;
