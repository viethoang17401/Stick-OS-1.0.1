import React from 'react';
import type { AppDefinition, ThemeDefinition, StoreItem } from './types';
import { Youtube, Facebook, Globe, Gamepad2, Bot, Code, Clapperboard, Settings, Rabbit, MousePointerClick, MemoryStick, ArrowUpFromDot, Bomb, Crosshair, Newspaper, Computer, Biohazard, ShoppingCart, Wallet, ShieldCheck, Soup } from 'lucide-react';

// Lazy load app components for better initial performance
const StickVideo = React.lazy(() => import('./apps/StickVideo'));
const StickFace = React.lazy(() => import('./apps/StickFace'));
const StickWeb = React.lazy(() => import('./apps/StickWeb'));
const GameOn = React.lazy(() => import('./apps/GameOn'));
const GptApp = React.lazy(() => import('./apps/GptApp'));
const RepApp = React.lazy(() => import('./apps/RepApp'));
const TrollApp = React.lazy(() => import('./apps/TrollApp'));
const SettingsApp = React.lazy(() => import('./apps/SettingsApp'));
const StickNews = React.lazy(() => import('./apps/StickNews'));
const ThisPCApp = React.lazy(() => import('./apps/ThisPCApp'));
const UiaVirusApp = React.lazy(() => import('./apps/UiaVirusApp'));
const StoreApp = React.lazy(() => import('./apps/StoreApp'));
const WalletApp = React.lazy(() => import('./apps/WalletApp'));
const AdBlockerApp = React.lazy(() => import('./apps/AdBlockerApp'));


// New Game App Components
const StickRunner = React.lazy(() => import('./apps/games/StickRunner'));
const StickClicker = React.lazy(() => import('./apps/games/StickClicker'));
const StickMemory = React.lazy(() => import('./apps/games/StickMemory'));
const StickJump = React.lazy(() => import('./apps/games/StickJump'));
const BotuBomb = React.lazy(() => import('./apps/games/BotuBomb'));
const FreeFireHTML5 = React.lazy(() => import('./apps/games/FreeFireHTML5'));
const PhoRestaurantGame = React.lazy(() => import('./apps/games/PhoRestaurantGame'));

// Desktop Pets/Widgets
const DesktopPetWalking = React.lazy(() => import('./components/desktop-widgets/DesktopPetWalking'));
const DesktopPetCatOnDock = React.lazy(() => import('./components/desktop-widgets/DesktopPetCatOnDock'));
const DesktopPetDogSniffing = React.lazy(() => import('./components/desktop-widgets/DesktopPetDogSniffing'));
const DesktopPetHamsterSleeping = React.lazy(() => import('./components/desktop-widgets/DesktopPetHamsterSleeping'));


export const APPS: AppDefinition[] = [
  {
    id: 'thispc',
    name: 'Máy tính này',
    icon: <Computer className="w-8 h-8 text-blue-400" />,
    component: ThisPCApp,
    defaultSize: { width: 750, height: 500 },
  },
  {
    id: 'stickvideo',
    name: 'StickVideo',
    icon: <Youtube className="w-8 h-8 text-red-500" />,
    component: StickVideo,
    defaultSize: { width: 800, height: 600 },
  },
  {
    id: 'stickface',
    name: 'StickFace',
    icon: <Facebook className="w-8 h-8 text-blue-600" />,
    component: StickFace,
    defaultSize: { width: 1000, height: 700 },
  },
  {
    id: 'stickweb',
    name: 'StickWeb',
    icon: <Globe className="w-8 h-8 text-yellow-500" />,
    component: StickWeb,
    defaultSize: { width: 900, height: 650 },
  },
  {
    id: 'gameon',
    name: 'Trung tâm Game',
    icon: <Gamepad2 className="w-8 h-8 text-green-500" />,
    component: GameOn,
    defaultSize: { width: 600, height: 400 },
  },
  {
    id: 'gptapp',
    name: 'Ứng dụng GPT',
    icon: <Bot className="w-8 h-8 text-purple-500" />,
    component: GptApp,
    defaultSize: { width: 500, height: 650 },
  },
  {
    id: 'repapp',
    name: 'Trình biên dịch',
    icon: <Code className="w-8 h-8 text-gray-800 dark:text-gray-200" />,
    component: RepApp,
    defaultSize: { width: 700, height: 500 },
  },
  {
    id: 'trollapp',
    name: 'Ứng dụng Chơi khăm',
    icon: <Clapperboard className="w-8 h-8 text-orange-500" />,
    component: TrollApp,
    defaultSize: { width: 300, height: 200 },
  },
  {
    id: 'settings',
    name: 'Cài đặt',
    icon: <Settings className="w-8 h-8 text-gray-500" />,
    component: SettingsApp,
    defaultSize: { width: 650, height: 500 },
  },
   {
    id: 'sticknews',
    name: 'Stick News',
    icon: <Newspaper className="w-8 h-8 text-blue-400" />,
    component: StickNews,
    defaultSize: { width: 750, height: 550 },
  },
  {
    id: 'store',
    name: 'Cửa hàng',
    icon: <ShoppingCart className="w-8 h-8 text-emerald-400" />,
    component: StoreApp,
    defaultSize: { width: 700, height: 550 },
  },
  {
    id: 'wallet',
    name: 'Ví Stickoin',
    icon: <Wallet className="w-8 h-8 text-yellow-400" />,
    component: WalletApp,
    defaultSize: { width: 400, height: 350 },
  },
   {
    id: 'adblocker',
    name: 'Trình chặn QC',
    icon: <ShieldCheck className="w-8 h-8 text-green-500" />,
    component: AdBlockerApp,
    defaultSize: { width: 350, height: 250 },
  },
  {
    id: 'uia-virus',
    name: 'UIA',
    icon: <Biohazard className="w-8 h-8 text-red-500" />,
    component: UiaVirusApp,
    defaultSize: { width: 300, height: 200 },
  },
  {
    id: 'stickrunner',
    name: 'Người Que Chạy',
    icon: <Rabbit className="w-8 h-8 text-cyan-400" />,
    component: StickRunner,
    defaultSize: { width: 400, height: 500 },
  },
  {
    id: 'stickclicker',
    name: 'Người Que Clicker',
    icon: <MousePointerClick className="w-8 h-8 text-amber-400" />,
    component: StickClicker,
    defaultSize: { width: 400, height: 500 },
  },
  {
    id: 'stickmemory',
    name: 'Trí nhớ Người Que',
    icon: <MemoryStick className="w-8 h-8 text-lime-400" />,
    component: StickMemory,
    defaultSize: { width: 400, height: 500 },
  },
  {
    id: 'stickjump',
    name: 'Người Que Nhảy',
    icon: <ArrowUpFromDot className="w-8 h-8 text-fuchsia-400" />,
    component: StickJump,
    defaultSize: { width: 400, height: 500 },
  },
  {
    id: 'botubomb',
    name: 'Bom Botu',
    icon: <Bomb className="w-8 h-8 text-rose-500" />,
    component: BotuBomb,
    defaultSize: { width: 400, height: 500 },
  },
  {
    id: 'freefirehtml5',
    name: 'Lửa Chùa HTML5',
    icon: <Crosshair className="w-8 h-8 text-orange-400" />,
    component: FreeFireHTML5,
    defaultSize: { width: 400, height: 500 },
  },
  {
    id: 'phorestaurant',
    name: 'Tiệm Phở Anh Hai',
    icon: <Soup className="w-8 h-8 text-orange-600" />,
    component: PhoRestaurantGame,
    defaultSize: { width: 400, height: 250 },
  },
];

export const STORE_ITEMS: StoreItem[] = [
    {
        id: 'pet_stickman_walking',
        name: 'Thú cưng Người Que',
        description: 'Một người bạn nhỏ đi lang thang trên màn hình của bạn. Không làm gì cả, chỉ để cho vui.',
        price: 300,
        tier: 'Pro',
        component: DesktopPetWalking,
    },
    {
        id: 'pet_cat_on_dock',
        name: 'Mèo Mun',
        description: 'Một chú mèo đen tinh nghịch thích chạy nhảy trên thanh Dock của bạn.',
        price: 400,
        tier: 'VIP',
        component: DesktopPetCatOnDock,
    },
    {
        id: 'pet_dog_sniffing',
        name: 'Chó LU',
        description: 'Một chú chó trung thành và tò mò, rất thích đi loanh quanh và "đánh hơi" các biểu tượng ứng dụng.',
        price: 600,
        tier: 'VIP',
        component: DesktopPetDogSniffing,
    },
    {
        id: 'pet_hamster_sleeping',
        name: 'Hamster Chụt Chụt',
        description: 'Một bé hamster đáng yêu chỉ muốn tìm một biểu tượng êm ái để ngả lưng và đánh một giấc.',
        price: 500,
        tier: 'VIP',
        component: DesktopPetHamsterSleeping,
    }
];

export const WALLPAPER_URL = "https://images.unsplash.com/photo-1502790671504-542ad42d5189?q=80&w=2070&auto=format&fit=crop";

export const PREDEFINED_WALLPAPERS = [
    { id: 'default', name: 'Mặc định Người Que', url: WALLPAPER_URL, thumbnailUrl: WALLPAPER_URL, type: 'image', tier: 'Free' },
    { id: 'minimal-dark', name: 'Tối giản', url: 'https://images.unsplash.com/photo-1534447677768-64483a0f71d1?q=80&w=2070&auto=format&fit=crop', thumbnailUrl: 'https://images.unsplash.com/photo-1534447677768-64483a0f71d1?q=80&w=2070&auto=format&fit=crop', type: 'image', tier: 'Free' },
    { id: 'gradient', name: 'Chuyển màu', url: 'https://images.unsplash.com/photo-1554034483-04fda0d3507b?q=80&w=2070&auto=format&fit=crop', thumbnailUrl: 'https://images.unsplash.com/photo-1554034483-04fda0d3507b?q=80&w=2070&auto=format&fit=crop', type: 'image', tier: 'Free' },
    { id: 'aichan', name: 'Chủ đề AI-chan', url: 'https://images.unsplash.com/photo-1507146426996-321341aa1ac5?q=80&w=2070&auto=format&fit=crop', thumbnailUrl: 'https://images.unsplash.com/photo-1507146426996-321341aa1ac5?q=80&w=2070&auto=format&fit=crop', type: 'image', tier: 'Pro' },
    { id: 'abstract-wave', name: 'Sóng Màu', url: 'https://images.unsplash.com/photo-1588345921523-c2dcdb7f1dcd?q=80&w=2070&auto=format&fit=crop', thumbnailUrl: 'https://images.unsplash.com/photo-1588345921523-c2dcdb7f1dcd?q=80&w=2070&auto=format&fit=crop', type: 'image', tier: 'Pro' },
    { id: 'botu', name: 'Meme Botu', url: 'https://images.unsplash.com/photo-1529426301869-82f4b86e0337?q=80&w=1968&auto=format&fit=crop', thumbnailUrl: 'https://images.unsplash.com/photo-1529426301869-82f4b86e0337?q=80&w=1968&auto=format&fit=crop', type: 'image', tier: 'VIP' },
    { id: 'animated-plexus', name: 'Mạng lưới Động', url: 'https://videos.pexels.com/video-files/856949/856949-hd_1920_1080_25fps.mp4', thumbnailUrl: 'https://images.pexels.com/videos/856949/pictures/preview-0.jpg', type: 'video', tier: 'VIP' },
    { id: 'scifi-city', name: 'Thành phố Viễn tưởng', url: 'https://images.unsplash.com/photo-1531554694128-c7d384350133?q=80&w=1974&auto=format&fit=crop', thumbnailUrl: 'https://images.unsplash.com/photo-1531554694128-c7d384350133?q=80&w=1974&auto=format&fit=crop', type: 'image', tier: 'VIP' },
    { id: 'dynamic', name: 'Ánh sáng Động', url: 'https://images.unsplash.com/photo-1531315630201-bb15ab376395?q=80&w=2070&auto=format&fit=crop', thumbnailUrl: 'https://images.unsplash.com/photo-1531315630201-bb15ab376395?q=80&w=2070&auto=format&fit=crop', type: 'image', tier: 'ULLTRA' },
    { id: 'cozy-room', name: 'Căn phòng Ấm cúng', url: 'https://images.unsplash.com/photo-1554995207-c18c203602cb?q=80&w=2070&auto=format&fit=crop', thumbnailUrl: 'https://images.unsplash.com/photo-1554995207-c18c203602cb?q=80&w=2070&auto=format&fit=crop', type: 'image', tier: 'ULLTRA' },
    { id: 'hacker', name: 'Chế độ Hacker', url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop', thumbnailUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop', type: 'image', tier: 'Super ULLTRA' },
    { id: 'deep-space', name: 'Không gian Sâu', url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop', thumbnailUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop', type: 'image', tier: 'Super ULLTRA' },
];

export const THEMES: ThemeDefinition[] = [
    {
        id: 'default',
        name: 'Mặc định Stick OS',
        tier: 'Free',
        colors: {
            '--primary-bg': '#0f172a',
            '--secondary-bg': '#1e293b',
            '--window-bg': 'rgba(30, 41, 59, 0.5)',
            '--header-bg': 'rgba(15, 23, 42, 0.7)',
            '--accent-color': '#3b82f6',
            '--accent-color-light': 'rgba(59, 130, 246, 0.5)',
            '--text-primary': '#ffffff',
            '--text-secondary': '#9ca3af',
            '--border-color': 'rgba(255, 255, 255, 0.1)',
            '--focus-ring-color': 'rgba(59, 130, 246, 0.5)',
        }
    },
    {
        id: 'hacker',
        name: 'Hacker Xanh lục',
        tier: 'Pro',
        colors: {
            '--primary-bg': '#05140a',
            '--secondary-bg': '#0a2914',
            '--window-bg': 'rgba(0, 20, 0, 0.5)',
            '--header-bg': 'rgba(0, 10, 0, 0.7)',
            '--accent-color': '#22c55e',
            '--accent-color-light': 'rgba(34, 197, 94, 0.5)',
            '--text-primary': '#22c55e',
            '--text-secondary': '#16a34a',
            '--border-color': 'rgba(34, 197, 94, 0.2)',
            '--focus-ring-color': 'rgba(34, 197, 94, 0.5)',
        }
    },
    {
        id: 'sunset',
        name: 'Hoàng hôn',
        tier: 'Pro',
        colors: {
            '--primary-bg': '#4a1d3b',
            '--secondary-bg': '#6b2d5a',
            '--window-bg': 'rgba(50, 31, 49, 0.5)',
            '--header-bg': 'rgba(35, 13, 32, 0.7)',
            '--accent-color': '#f97316',
            '--accent-color-light': 'rgba(249, 115, 22, 0.5)',
            '--text-primary': '#fed7aa',
            '--text-secondary': '#fdba74',
            '--border-color': 'rgba(249, 115, 22, 0.2)',
            '--focus-ring-color': 'rgba(249, 115, 22, 0.5)',
        }
    },
    {
        id: 'ocean',
        name: 'Đại dương',
        tier: 'Pro',
        colors: {
            '--primary-bg': '#0c2638',
            '--secondary-bg': '#12344b',
            '--window-bg': 'rgba(15, 45, 65, 0.5)',
            '--header-bg': 'rgba(8, 28, 42, 0.7)',
            '--accent-color': '#2dd4bf',
            '--accent-color-light': 'rgba(45, 212, 191, 0.5)',
            '--text-primary': '#e0f2f1',
            '--text-secondary': '#b2dfdb',
            '--border-color': 'rgba(45, 212, 191, 0.2)',
            '--focus-ring-color': 'rgba(45, 212, 191, 0.5)',
        }
    },
    {
        id: 'amethyst',
        name: 'Thạch anh tím',
        tier: 'VIP',
        colors: {
            '--primary-bg': '#3b1c5a',
            '--secondary-bg': '#522a7e',
            '--window-bg': 'rgba(45, 26, 70, 0.5)',
            '--header-bg': 'rgba(30, 13, 52, 0.7)',
            '--accent-color': '#a855f7',
            '--accent-color-light': 'rgba(168, 85, 247, 0.5)',
            '--text-primary': '#f3e8ff',
            '--text-secondary': '#e9d5ff',
            '--border-color': 'rgba(168, 85, 247, 0.2)',
            '--focus-ring-color': 'rgba(168, 85, 247, 0.5)',
        }
    },
    {
        id: 'cherry',
        name: 'Anh đào',
        tier: 'VIP',
        colors: {
            '--primary-bg': '#50303e',
            '--secondary-bg': '#70485c',
            '--window-bg': 'rgba(60, 50, 55, 0.5)',
            '--header-bg': 'rgba(40, 30, 35, 0.7)',
            '--accent-color': '#f472b6',
            '--accent-color-light': 'rgba(244, 114, 182, 0.5)',
            '--text-primary': '#fce7f3',
            '--text-secondary': '#f9a8d4',
            '--border-color': 'rgba(244, 114, 182, 0.2)',
            '--focus-ring-color': 'rgba(244, 114, 182, 0.5)',
        }
    },
    {
        id: 'botu',
        name: 'Botu Hủy diệt',
        tier: 'ULLTRA',
        colors: {
            '--primary-bg': '#450a0a',
            '--secondary-bg': '#5f1010',
            '--window-bg': 'rgba(50, 15, 15, 0.5)',
            '--header-bg': 'rgba(35, 5, 5, 0.7)',
            '--accent-color': '#ef4444',
            '--accent-color-light': 'rgba(239, 68, 68, 0.5)',
            '--text-primary': '#fecaca',
            '--text-secondary': '#fca5a5',
            '--border-color': 'rgba(239, 68, 68, 0.3)',
            '--focus-ring-color': 'rgba(239, 68, 68, 0.5)',
        }
    },
    {
        id: 'retro',
        name: 'Retro 8-bit',
        tier: 'ULLTRA',
        colors: {
            '--primary-bg': '#1d1544',
            '--secondary-bg': '#2a2155',
            '--window-bg': 'rgba(35, 27, 75, 0.5)',
            '--header-bg': 'rgba(20, 15, 55, 0.7)',
            '--accent-color': '#ff00ff',
            '--accent-color-light': 'rgba(255, 0, 255, 0.5)',
            '--text-primary': '#00ffff',
            '--text-secondary': '#a0a0ff',
            '--border-color': 'rgba(0, 255, 255, 0.3)',
            '--focus-ring-color': 'rgba(255, 0, 255, 0.5)',
        }
    },
];